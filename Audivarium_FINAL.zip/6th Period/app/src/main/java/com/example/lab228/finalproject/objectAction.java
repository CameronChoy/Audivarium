package com.example.lab228.finalproject;

import android.util.Log;

import java.util.Random;

public class objectAction {
    private actionType actionType;
    private int objectId, startFrame, currentFrame,duration;
    private double speedX,speedY,startX,startY;
    private double rotationAngle,startAlpha;
    private float endX,endY,dX,dY;
    private boolean actionBoolean;
    private double newRed,newGreen,newBlue;
    private final int LASER_FRAME_DURATION = 150;
    private final int EXPLODE_FRAME_DURATION = 120;
    private final int EXPLODE_OUT_FRAME_DURATION =  EXPLODE_FRAME_DURATION/2;
    private float prevRight,prevBottom;
    Random random = new Random();

    /*
        Notes: dX,dY becomes right, bottom, for reset action
        dX becomes rotation angle for rotation action

        actionBoolean is different boolean for each action, duh
            rotate=isCounterCLockwise
           laser=isVertical
           reset=isSquare
           explodeIn and out = israndomlocation
           translate = stopsInMap (if true does actual speed it should be at)

        red becomes screenShake
        rotation becomes newAlpha in reset and newalpha
     */
    public objectAction( int id, int startFrame, int duration, float dX, float dY, int rotation, boolean actionBoolean, int red, int green, int blue, float endX,float endY,actionType type){
        actionType = type;
        objectId = id;
        this.startFrame = startFrame;
        this.dX=dX;
        this.dY=dY;
        this.duration=duration;
        startAlpha=0;
        currentFrame = 0;
        this.rotationAngle=rotation;
        this.actionBoolean = actionBoolean;
        newRed = red;
        newGreen=green;
        newBlue=blue;
        this.endX = endX;
        this.endY=endY;
        speedX=Math.abs(getdX()/(getDuration()));
        speedY=Math.abs(getdY()/(getDuration()));
    }

    public void buildAction(){
        switch (getType()){
            case TRANSLATE:
                dX = (getdX() == 10f) ? 0.5f : getdX() * myCanvas.width;
                dY = (getdY() == 10f) ? 0.5f : getdY() * myCanvas.height;
                break;

            case LASER: {
                duration = LASER_FRAME_DURATION;
                if (dX == 10f) {
                    dX = random.nextFloat() * myCanvas.width;
                    dY = random.nextFloat() * myCanvas.height;
                }
                else {
                    dX = getdX() * myCanvas.width;
                    dY = getdY() * myCanvas.height;
                }
                break;
            }

            case EXPLODEIN: {
                duration = EXPLODE_FRAME_DURATION;
                if (actionBoolean) {
                    dX = random.nextFloat() * myCanvas.width;
                    dY = random.nextFloat() * myCanvas.height;
                }
                else {
                    dX = getdX() * myCanvas.width;
                    dY = getdY() * myCanvas.height;
                }
                break;
            }

            case EXPLODEOUT: {
                duration = EXPLODE_OUT_FRAME_DURATION;
                if (actionBoolean) {
                    this.dX = random.nextFloat() * myCanvas.width;
                    this.dY = random.nextFloat() * myCanvas.height;
                }
                else {
                    dX = getdX() * myCanvas.width;
                    dY = getdY() * myCanvas.height;
                }
                break;
            }

            default:
                dX = getdX() * myCanvas.width;
                dY = getdY() * myCanvas.height;
                break;
        }

        endX=getEndX()*myCanvas.width;
        endY=getEndY()*myCanvas.height;
        speedX = (dX == .05f) ? 0 : getdX() / (getDuration());
        speedY=(dY == .05f) ? 0 : getdY()/(getDuration());
    }

    private final float LASER_PHASE_1_FRAME = (LASER_FRAME_DURATION*0.4f);
    private final int LASER_PHASE_2_FRAME = (int)((LASER_FRAME_DURATION*0.4)+LASER_PHASE_1_FRAME);//frame when phase 2 starts
    private final int LASER_LAST_FRAME = (int)((LASER_FRAME_DURATION*0.2)+LASER_PHASE_2_FRAME);//final frame
    private final int LASER_LAST_PHASE_DURATION = LASER_LAST_FRAME-LASER_PHASE_2_FRAME;//frame length of final phase
    private final float LASER_APPEAR = 255/LASER_PHASE_2_FRAME;//amount of alpha per frame
    private final float LASER_FADE = 1000/LASER_PHASE_2_FRAME;//amount of alpha per frame
    private final float LASERSCALE = .05f;

    private final float EXPLODE_PHASE_1_FRAME = (EXPLODE_FRAME_DURATION*0.4f);
    private final int EXPLODE_PHASE_2_FRAME = (int)((EXPLODE_FRAME_DURATION*0.4)+EXPLODE_PHASE_1_FRAME);//frame when phase 2 starts
    private final int EXPLODE_LAST_FRAME = (int)((EXPLODE_FRAME_DURATION*0.2)+EXPLODE_PHASE_2_FRAME);//final frame
    private final int EXPLODE_LAST_PHASE_DURATION = EXPLODE_LAST_FRAME-EXPLODE_PHASE_2_FRAME;//frame length of final phase
    private final float EXPLODE_PHASE_2_ALPHA_APPEAR = 255/EXPLODE_PHASE_2_FRAME; //amount of alpha per frame, both explode out and in
    final float EXPLODE_OUT_ALPHA_FADE = (459/(EXPLODE_PHASE_2_FRAME));//amount of alpha per frame, only explode out

    public void doAction(){
        int idObject = getObjectId();
        switch (getType()){

            case LASER:{
                switch(getCurrentFrame()){
                    //Setup
                    case 0:{
                        prevRight =  myCanvas.levelObjects[idObject].getRight();
                        prevBottom =  myCanvas.levelObjects[idObject].getBottom();
                        myCanvas.levelObjects[idObject].updateObjectColor(0,
                                myCanvas.mainRed,
                                myCanvas.mainGreen,
                                myCanvas.mainBlue);
                        myCanvas.levelObjects[idObject].updateDoesDamage(false);
                        if(getactionBoolean()){
                            myCanvas.levelObjects[idObject].updateShape(myCanvas.width*LASERSCALE,myCanvas.height*2);
                            myCanvas.levelObjects[idObject].updateCoordinates(getdX(),0);}
                        else{
                            myCanvas.levelObjects[idObject].updateShape(myCanvas.width*2,myCanvas.width*LASERSCALE);
                            myCanvas.levelObjects[idObject].updateCoordinates(0,getdY());}
                        break;
                    }
                    //Explode
                    case LASER_PHASE_2_FRAME:{
                        myCanvas.levelObjects[idObject].updateObjectColor(255,255,255,255);
                        myCanvas.levelObjects[idObject].updateDoesDamage(true);
                        break;
                    }
                    case LASER_PHASE_2_FRAME+1:{
                        myCanvas.levelObjects[idObject].updateDoesDamage(false);
                        myCanvas.levelObjects[idObject].updateObjectColor((myCanvas.levelObjects[idObject].getAlpha()-LASER_FADE),
                                (myCanvas.levelObjects[idObject].getRed()-((double)(255-myCanvas.mainRed)/LASER_LAST_PHASE_DURATION)),
                                (myCanvas.levelObjects[idObject].getGreen()-(double)(((255-myCanvas.mainGreen)/LASER_LAST_PHASE_DURATION))),
                                (myCanvas.levelObjects[idObject].getBlue()-(double)(((255-myCanvas.mainBlue)/LASER_LAST_PHASE_DURATION))));
                        break;
                    }
                    //Done
                    case LASER_LAST_FRAME:{
                        myCanvas.levelObjects[idObject].updateShape(getPrevRight(),getPrevBottom());
                        myCanvas.levelObjects[idObject].updateObjectColor(0,
                                myCanvas.mainRed,
                                myCanvas.mainGreen,
                                myCanvas.mainBlue);
                        myCanvas.levelObjects[idObject].updateCoordinates(getEndX(),getEndY());
                        break;
                    }
                    default:{
                        //Appearing
                        if(getCurrentFrame()<LASER_PHASE_2_FRAME){
                            myCanvas.levelObjects[idObject].updateObjectColor((myCanvas.levelObjects[idObject].getAlpha()+LASER_APPEAR),
                                    myCanvas.mainRed,
                                    myCanvas.mainGreen,
                                    myCanvas.mainBlue);
                        }
                        //Fading
                        else if(getCurrentFrame()<LASER_LAST_FRAME){
                            myCanvas.levelObjects[idObject].updateObjectColor( (myCanvas.levelObjects[idObject].getAlpha()-LASER_FADE),
                                    myCanvas.levelObjects[idObject].getRed()-((255-myCanvas.mainRed)/LASER_LAST_PHASE_DURATION),
                                    myCanvas.levelObjects[idObject].getGreen()-((255-myCanvas.mainGreen)/LASER_LAST_PHASE_DURATION),
                                    myCanvas.levelObjects[idObject].getBlue()-((255-myCanvas.mainBlue)/LASER_LAST_PHASE_DURATION));
                        }
                    }
                }
                addFrame();
                return;}

            case RESET:{
                myCanvas.levelObjects[idObject].updateCoordinates(getEndX(),getEndY());
                myCanvas.levelObjects[idObject].updateObjectColor(getRotationAngle(), getnewRed(),getNewGreen(),getNewBlue());
                myCanvas.levelObjects[idObject].updateIsSquare(getactionBoolean());
                if(getactionBoolean())
                    myCanvas.levelObjects[idObject].updateShape(getdX(),getdX());

                else myCanvas.levelObjects[idObject].updateShape(getdX(),getdY());
                myCanvas.levelObjects[idObject].updateDoesDamage(true);
                myCanvas.levelObjects[idObject].updateIsRotating(false);
                addFrame();
                // Log.i("reset","reset " + myCanvas.levelObjects[idObject].getX() + " " + game.frameCount);
                // Log.i("reset","reset " + myCanvas.levelObjects[idObject].getY() + " " +myCanvas.levelObjects[idObject].getX()+ " " +myCanvas.levelObjects[idObject].getRight()+ " " +myCanvas.levelObjects[idObject].getBottom());
                return;}

            case ROTATE:
                if(getCurrentFrame()==0)
                {myCanvas.levelObjects[idObject].updateIsRotating(true);
                    myCanvas.levelObjects[idObject].updateRotationPoint(getdX(),getdY());
                    //Log.i("rotate","rotate " + myCanvas.levelObjects[idObject].getRotationOriginX() + " " + myCanvas.levelObjects[idObject].getRotationOriginY());
                }
                else if(getCurrentFrame()>=getDuration()){
                    myCanvas.levelObjects[idObject].updateIsRotating(false);
                    myCanvas.levelObjects[idObject].updateCoordinates(getEndX(),getEndY());
                    addFrame();
                    return;
                }
                if(getactionBoolean()){
                    myCanvas.levelObjects[idObject].updateRotation((myCanvas.levelObjects[idObject].getRotation()+(getRotationAngle()/getDuration())));
                    //Log.i("rotate","rotate+ " + (myCanvas.levelObjects[idObject].getRotation()+(getRotationAngle()/getDuration())));
                     }
                else
                {myCanvas.levelObjects[idObject].updateRotation((myCanvas.levelObjects[idObject].getRotation()-(getRotationAngle()/getDuration())));
                //Log.i("rotate","rotate- " + (myCanvas.levelObjects[idObject].getRotation()-(getRotationAngle()/getDuration())));
                     }
                addFrame();
                return;

            case NEWCOLOR:
                myCanvas.levelObjects[idObject].updateObjectColor(myCanvas.levelObjects[idObject].getAlpha(),getnewRed(),getNewGreen(),getNewBlue());
                addFrame();
                return;

            case NEWALPHA:
                if(getCurrentFrame()==0){
                    startAlpha=myCanvas.levelObjects[idObject].getAlpha();
                }
                if(myCanvas.levelObjects[idObject].getAlpha() > getRotationAngle()){//fade
                    myCanvas.levelObjects[idObject].updateAlpha((myCanvas.levelObjects[idObject].getAlpha()-((getStartAlpha() - getRotationAngle())/getDuration())));
                    if(myCanvas.levelObjects[idObject].getAlpha()<=0){
                        currentFrame=duration;
                        myCanvas.levelObjects[idObject].updateAlpha(0);
                    }
                    //Log.i("newAlpha","fade " + (myCanvas.levelObjects[idObject].getAlpha()-((getStartAlpha() - getRotationAngle())/(double)getDuration())));
                }

                else{//appear
                    myCanvas.levelObjects[idObject].updateAlpha((myCanvas.levelObjects[idObject].getAlpha()+((getRotationAngle() - getStartAlpha())/getDuration())));
                    //Log.i("newAlpha","appear " + myCanvas.levelObjects[idObject].getAlpha()+ " " +((float)(getRotationAngle() + getStartAlpha())/getDuration()));
                }

                addFrame();
                return;

            case EXPLODEIN:
                switch(getCurrentFrame()){
                    case 0:
                        myCanvas.levelObjects[idObject].updateObjectColor(0,myCanvas.mainRed,myCanvas.mainGreen,myCanvas.mainBlue);
                        myCanvas.levelObjects[idObject].updateDoesDamage(false);
                        myCanvas.levelObjects[idObject].updateCoordinates(getdX(),getdY());
                        break;
                    case EXPLODE_PHASE_2_FRAME:
                        myCanvas.levelObjects[idObject].updateObjectColor(255,255,255,255);
                        myCanvas.levelObjects[idObject].updateDoesDamage(true);
                        break;
                    case EXPLODE_PHASE_2_FRAME+1:{
                        myCanvas.levelObjects[idObject].updateObjectColor(255,
                                myCanvas.levelObjects[idObject].getRed()-((255-myCanvas.mainRed)/EXPLODE_LAST_PHASE_DURATION),
                                myCanvas.levelObjects[idObject].getGreen()-((255-myCanvas.mainGreen)/EXPLODE_LAST_PHASE_DURATION),
                                myCanvas.levelObjects[idObject].getBlue()-((255-myCanvas.mainBlue)/EXPLODE_LAST_PHASE_DURATION));
                        break;
                    }
                    case EXPLODE_LAST_FRAME://final frame
                        myCanvas.levelObjects[idObject].updateObjectColor(255,myCanvas.mainRed,myCanvas.mainGreen,myCanvas.mainBlue);
                        break;

                    default:
                        if(getCurrentFrame()<EXPLODE_PHASE_2_FRAME){//appearing
                            myCanvas.levelObjects[idObject].updateObjectColor((myCanvas.levelObjects[idObject].getAlpha()+EXPLODE_PHASE_2_ALPHA_APPEAR),
                                    myCanvas.mainRed,
                                    myCanvas.mainGreen,
                                    myCanvas.mainBlue);
                        }
                        else {
                            myCanvas.levelObjects[idObject].updateObjectColor(255,
                                    myCanvas.levelObjects[idObject].getRed()-((255-myCanvas.mainRed)/EXPLODE_LAST_PHASE_DURATION),
                                    myCanvas.levelObjects[idObject].getGreen()-((255-myCanvas.mainGreen)/EXPLODE_LAST_PHASE_DURATION),
                                    myCanvas.levelObjects[idObject].getBlue()-((255-myCanvas.mainBlue)/EXPLODE_LAST_PHASE_DURATION));
                        }

                }
                addFrame();
                return;

            case TRANSLATE:
                if(getCurrentFrame()==0 && getactionBoolean()){ // if stopping on screen for exact speed and positioning
                    startY=myCanvas.levelObjects[idObject].getY();
                    startX=myCanvas.levelObjects[idObject].getX();

                    if(getdX()!=0.5f){
                        speedX = Math.abs((startX - getdX()) / getDuration());
                    //Log.i("actiondo","speedX" +getdX());
                         }
                    else
                        speedX=0;

                    if(getdY()!=0.5f)
                        speedY=Math.abs((startY-getdY())/getDuration());
                    else
                        speedY=0;
                   //Log.i("actiondo","start speedX: " + getSpeedX() + " speedY: " + getSpeedY() + " startX: " + getStartX() + " startY: " + getStartY());
                }

                if (getdX() > myCanvas.levelObjects[idObject].getX()) {//if going right
                    myCanvas.levelObjects[getObjectId()].updateCoordinates((float)((myCanvas.levelObjects[idObject].getX()) + getSpeedX()),
                            myCanvas.levelObjects[idObject].getY());
                }
                else {//if (getdX() < myCanvas.levelObjects[idObject].getX()) {//if going left
                    myCanvas.levelObjects[getObjectId()].updateCoordinates((float)((myCanvas.levelObjects[idObject].getX()) - Math.abs(getSpeedX())),
                            myCanvas.levelObjects[idObject].getY());
                }

                if (getdY() > myCanvas.levelObjects[idObject].getY()) {  //if going down
                    myCanvas.levelObjects[getObjectId()].updateCoordinates(myCanvas.levelObjects[idObject].getX(),
                            (float)(myCanvas.levelObjects[idObject].getY() + getSpeedY()));
                }
                else {//if (getdY() < myCanvas.levelObjects[idObject].getY()) {//if going up
                    myCanvas.levelObjects[getObjectId()].updateCoordinates(myCanvas.levelObjects[idObject].getX(),
                            (float)(myCanvas.levelObjects[idObject].getY() - Math.abs(getSpeedY())));
                }


                //Log.i("actiondo", "move " + game.frameCount + " " + idObject + " " + myCanvas.levelObjects[idObject].getX());
                addFrame();
                return;

            case EXPLODEOUT:
                switch(getCurrentFrame()) {
                    case 0:
                        myCanvas.levelObjects[idObject].updateObjectColor(255,255,255,255);
                        myCanvas.levelObjects[idObject].updateDoesDamage(true);
                        break;

                    case 1:
                        myCanvas.levelObjects[idObject].updateDoesDamage(false);
                        myCanvas.levelObjects[idObject].updateObjectColor((myCanvas.levelObjects[idObject].getAlpha()-EXPLODE_OUT_ALPHA_FADE),
                                myCanvas.levelObjects[idObject].getRed()-((255-myCanvas.mainRed)/(EXPLODE_OUT_FRAME_DURATION)),
                                myCanvas.levelObjects[idObject].getGreen()-((255-myCanvas.mainGreen)/(EXPLODE_OUT_FRAME_DURATION)),
                                myCanvas.levelObjects[idObject].getBlue()-((255-myCanvas.mainBlue)/(EXPLODE_OUT_FRAME_DURATION)));
                        break;
                    case EXPLODE_OUT_FRAME_DURATION:
                        myCanvas.levelObjects[idObject].updateObjectColor(0,myCanvas.mainRed,myCanvas.mainGreen,myCanvas.mainBlue);
                        myCanvas.levelObjects[idObject].updateCoordinates(getEndX(),getEndY());
                        break;

                    default:
                        myCanvas.levelObjects[idObject].updateObjectColor((myCanvas.levelObjects[idObject].getAlpha()-EXPLODE_OUT_ALPHA_FADE),
                                myCanvas.levelObjects[idObject].getRed()-((255-myCanvas.mainRed)/EXPLODE_OUT_FRAME_DURATION),
                                myCanvas.levelObjects[idObject].getGreen()-((255-myCanvas.mainGreen)/EXPLODE_OUT_FRAME_DURATION),
                                myCanvas.levelObjects[idObject].getBlue()-((255-myCanvas.mainBlue)/EXPLODE_OUT_FRAME_DURATION));
                        break;
                }
                addFrame();
                return;

            case SCREENSHAKE:
                if(getCurrentFrame()>=getDuration()-1){
                    myCanvas.screenShaking=false;
                }
                else if(getCurrentFrame()==0){
                    myCanvas.screenShaking=true;
                    myCanvas.screenShake= new int[]{(int)getnewRed(),(int)-getnewRed()};}

                addFrame();
                break;

            case NEWSHAPE: //basically shape reset
                myCanvas.levelObjects[idObject].updateCoordinates(getEndX(),getEndY());
                if(getnewRed()==1)
                    myCanvas.levelObjects[idObject].updateShape(getdX(),getdX());
                else
                    myCanvas.levelObjects[idObject].updateShape(getdX(),getdY());
                myCanvas.levelObjects[idObject].updateDoesDamage(getactionBoolean());
                myCanvas.levelObjects[idObject].updateObjectColor(getRotationAngle(),myCanvas.mainRed,myCanvas.mainGreen,myCanvas.mainBlue);
                addFrame();
                break;

        }
    }



    public void addFrame(){
        currentFrame++;
    }

    public actionType getType(){
        return actionType;
    }

    public boolean getactionBoolean() {
        return actionBoolean;
    }

    public double getnewRed() {
        return newRed;
    }

    public double getNewBlue() { return newBlue; }

    public double getNewGreen(){ return newGreen; }

    public int getObjectId(){
        return objectId;
    }

    public double getStartAlpha(){
        return startAlpha;
    }

    public int getStartFrame(){
        return startFrame;
    }

    public int getCurrentFrame() {
        return currentFrame;
    }

    public double getStartX() {
        return startX;
    }

    public double getStartY() {
        return startY;
    }

    public int getDuration() {
        return duration;
    }

    public float getdX() {
        return dX;
    }

    public float getdY() {
        return dY;
    }

    public double getRotationAngle(){
        return rotationAngle;
    }

    public float getPrevRight() {
        return prevRight;
    }

    public float getPrevBottom() {
        return prevBottom;
    }

    public float getEndX() { return endX; }

    public float getEndY() { return endY; }

    public double getSpeedY() {
        return speedY;
    }

    public double getSpeedX() {
        return speedX;
    }
}
