package com.example.lab228.finalproject;

import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.SurfaceView;
import android.view.View;

import java.util.TimerTask;
import java.util.Timer;

public class game extends AppCompatActivity {
    static myCanvas canvas;
    static int levelID;
    static int playerHealth = 5;
    static double frameCount = 0;
    static int songCurrentTime = 0;
    static float songFrameTime;
    SurfaceView layout;
    static MediaPlayer song,hit,gameOver;
    static boolean songLoaded = false;
    static boolean soundsLoaded = false;
    static boolean random = false;
    static boolean gameIsOver = false;
    static boolean quitting = false;
    static boolean gameRunning = false;
    static boolean levelCompleted = false;
    Handler handler = new Handler();
    Timer timer;
    TimerTask timerTask;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //Log.i("testingLoop","beginning");
        gameIsOver=false;
        quitting=false;
        songLoaded=false;
        soundsLoaded=false;
        songCurrentTime=0;
        levelCompleted=false;
        playerHealth=5;
        gameRunning=true;
        resetFrameCount();

        levelID = getIntent().getIntExtra("level",0);
        random = Levels.totalLevels[levelID].isRandom();

        try{
            song = MediaPlayer.create(getApplicationContext(), Levels.totalLevels[levelID].getSongId());
            //Log.i("songstuff","got " + Levels.totalLevels[levelID].getSongId());
           songLoaded=true;
        }
        catch(Exception e){
            try {
                songFrameTime = Levels.totalLevels[levelID].getLevelActions()[Levels.totalLevels[levelID].getLevelActions().length - 1].getStartFrame() + 500;
            }
            catch (ArrayIndexOutOfBoundsException c){
                songFrameTime=0;}
        }

        try{
            hit = MediaPlayer.create(getApplicationContext(), R.raw.hit);
            gameOver = MediaPlayer.create(getApplicationContext(),R.raw.gameover);
            songFrameTime=song.getDuration()/17f;
            soundsLoaded=true;
        }
        catch (Exception ignored){}

        canvas = new myCanvas(this);
        canvas.setBackgroundColor(Color.DKGRAY);
        setContentView(canvas);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            canvas.setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN);
        }
        canvas.invalidate();

        if(songLoaded) {
            //Log.i("songstuff","start " + song.getDuration());
            song.start();
            if(random){
                song.setLooping(true);
            }
        }
        startGameLoop();
    }

    public static void damaged(){
        playerHealth--;
        if(playerHealth>0){//oof
            if(soundsLoaded) {
                hit.start();
            }
        }
        else{//lose
            if(soundsLoaded) {
                gameOver.start();}
            if(songLoaded) {
                song.stop();}

            gameRunning=false;
            gameIsOver=true;
        }
    }

    public void quitGame(int endGame){
        Intent intent;
        //Log.i("gameDone","done");
        switch(endGame){
            case 1://quit game
                intent = new Intent(this, SelectLevel.class);
                break;

            case 2://completed level
                intent = new Intent(this, levelOver.class);
                intent.putExtra("didWin",true);
                intent.putExtra("levelID",levelID);
                break;

            case 3://got heckin dead
                intent = new Intent(this, levelOver.class);
                intent.putExtra("didWin",false);
                intent.putExtra("levelID",levelID);
                if(random) {
                    intent.putExtra("frameCount", (int)frameCount);
                }
                break;

                default:
                    intent = new Intent(this, SelectLevel.class);
                    break;
        }
        if(songLoaded){
            song.stop();
            //song.reset();
            song.release();
            song=null;
            songLoaded=false;
        }
        startActivity(intent);
        overridePendingTransition(R.anim.zoom_in,R.anim.zoom_out);
        try {
            Thread.sleep(300);
        } catch (InterruptedException ignored) { }
    }

    public void startGameLoop(){
        timer = new Timer();
        gameLoop();
        timer.scheduleAtFixedRate(timerTask, 0, 17);
    }

    public void gameLoop(){
        timerTask = new TimerTask() {
            public void run(){
                handler.post(new Runnable(){
                    public void run() {
                        //Log.i("testingLoop", "run "+gameRunning + " " + frameCount);
                        if(gameRunning) {
                            canvas.invalidate();
                            frameCount++;

                            if(frameCount>=songFrameTime && !random){
                                    gameRunning = false;
                                    gameIsOver = true;
                                    levelCompleted = true;
                                }

                            //if(frameCount%61 == 60)
                            //Log.i("second", "pass " + frameCount);
                            //Log.i("testingLoop", frameCount + " / " + songFrameTime);
                        }
                        else {
                            stopSong();
                            if(quitting){
                                timerTask.cancel();
                                timer.cancel();
                                stopSong();
                                quitting=false;
                                gameIsOver=false;
                                 quitGame(1);//quit
                            }
                            else if(gameIsOver){
                                timerTask.cancel();
                                timer.cancel();
                                if(levelCompleted){
                                    quitGame(2);//win
                                }
                                else
                                    quitGame(3);//lost
                            }
                             if(!myCanvas.gamePaused){
                                gameRunning=true;
                                startSong();
                            }
                        }
                    }
                });
            }
        };
    }

    public void resetFrameCount(){ frameCount = 0;}

    public void stopSong(){
        if(songLoaded) {
            song.pause();
            songCurrentTime = song.getCurrentPosition();
        }
    }

    public static void startSong(){
        if(songLoaded) {
            song.seekTo(songCurrentTime);
            song.start();
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        gameRunning = true;
        startSong();
        //Log.i("testingLoop","resume");
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            canvas.setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN);
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        stopSong();
        gameRunning = false;
       // Log.i("stoploop","pause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        stopSong();
        gameRunning = false;
        //Log.i("stoploop","stop");
    }

}
