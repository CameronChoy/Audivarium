package com.example.lab228.finalproject;

import android.graphics.Paint;

public class gameObject {
    private float posX,posY,right,bottom;
    private boolean doesDamage,isRotating,isSquare;
    private Paint objectColor;
    private double alpha,red,green,blue, rotation;
    private float rotationOriginX,rotationOriginY;
    public gameObject(float x, float y, float right, float bottom, boolean doesDamage, boolean isRotating, boolean isSquare, double alpha, double red,double green, double blue, double rotation){
        posX = x;
        this.posY = y;
        this.right = right;

        this.isSquare=isSquare;
        if(!isSquare)
               this.bottom = bottom;

        else
            this.bottom = this.right;

        this.doesDamage = doesDamage;
        this.isRotating = isRotating;
        this.alpha = alpha;
        this.objectColor = new Paint();
        this.red=red;
        this.green=green;
        this.blue=blue;
        this.objectColor.setARGB((int)alpha,(int)red,(int)green,(int)blue);
        this.objectColor.setStyle(Paint.Style.FILL);
        this.rotation = rotation;
        rotationOriginX=0;
        rotationOriginY=0;
    }

    public  void updateCoordinates(float newX, float newY){
        posX = newX;
        posY = newY;
    }

    public void updateShape(float newRight, float newBottom){
        right = newRight;
        bottom = newBottom;
    }

    public void updateRotationPoint(float x, float y){
        rotationOriginX=x;
        rotationOriginY=y;
         }


    public  void updateDoesDamage(boolean x){
        doesDamage = x;
    }
    public void updateRotation(double newRotation){rotation=newRotation;}
    public void updateIsSquare(boolean x){isSquare=x;}

    public  void updateIsRotating(boolean x){
        isRotating = x;
    }

    public void updateObjectColor(double a, double r, double g, double b){objectColor.setARGB((int)a,(int)r,(int)g,(int)b);
        alpha=a;
        red=r;
        green=g;
        blue=b;}

    public void updateAlpha(double a){
        objectColor.setAlpha((int)a);
        alpha=a;
    }

    public float getRotationOriginX(){
        return rotationOriginX;
    }

    public float getRotationOriginY() {
        return rotationOriginY;
    }

    public boolean getDoesDamage(){
        return doesDamage;
    }

    public boolean getIsSquare(){
        return isSquare;
    }

    public float getX(){
        return posX;
    }
    public float getY(){
        return posY;
    }
    public double getRotation(){
        return rotation;
    }

    public float getRight(){
        return right;
    }

    public float getBottom(){
        return bottom;
    }

    public boolean getisRotating(){
        return isRotating;
    }

    public double getAlpha(){
        return alpha;
    }

    public Paint getobjectColor(){
        return objectColor;
    }

    public double getGreen() { return green; }

    public double getBlue() { return blue; }

    public double getRed() { return red; }
}
