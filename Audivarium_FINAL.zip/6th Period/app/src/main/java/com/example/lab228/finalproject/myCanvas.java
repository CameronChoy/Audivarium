package com.example.lab228.finalproject;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Build;
import android.support.annotation.RequiresApi;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import java.util.ArrayList;
import java.util.Random;

public class myCanvas extends View {
    static int height=1920;
    static int width=1080;
    Random choose = new Random();
    int controllerCenterX,controllerCenterY;
    int controllerMaxRadius;
    int touchRadius;
    int maxSpeed;
    int random,randomId;
    static int[] screenShake = {0,0};
    static int mainRed,mainBlue,mainGreen;
    private int immunityFrames=0;
    double touchDir;
    double disX,disY,posTryX,posTryY;
    double borderAdditionScale = (75.0/2)/1920;
    double ratio;
    double playerscale = 75.0/1920;
    double borderScaleWidth;
    double borderScaleWidthMinusWidth;
    double borderScaleHeight;
    double borderScaleHeightMinusHeight;
    boolean doneAddingActions = false;
    static boolean screenShaking = false;
    boolean touchingScreen = false;
    boolean gameStarted = true;
    boolean damaged =false;
    float touchX,touchY;
    float pauseCircle = width*.04f;
    float pauseButtonHitbox = pauseCircle*2.5f;
    float pauseRectTop = height*.03f;
    float pauseRectBottom = height*.11f;
    float progressSpeed = 1;
    float randomdX,randomdY,randomEndX,randomEndY;
    float titleTextX = 0;
    float titleTextY = 0;
    float titleSpeed;
    float textQuitWidth,textPausedWidth,textTouchWidth;
    Paint controllerColor = new Paint();
    Paint pauseButton = new Paint();
    Paint playerColor = new Paint();
    Paint pauseText = new Paint();
    Paint progressBarColor = new Paint();
    Paint healthText = new Paint();
    Paint titleText = new Paint();
    Rect progressBar  = new Rect();
    static Rect player = new Rect(0,0,75,75);
    static Rect currentObject = new Rect(300,300,400,400);
    static gameObject[] levelObjects;
    static ArrayList<objectAction> totalLevelActions;
    static ArrayList<objectAction> currentLevelActions;
    ArrayList<objectAction> removedActions;
    actionType randomType;

    public myCanvas(Context context) {
        super(context);
        controllerColor.setARGB(80,108, 109, 105);
        pauseButton.setColor(Color.BLACK);
        pauseButton.setAlpha(50);
    }

    /*  modified touch event
       https://www.instructables.com/id/A-Simple-Android-UI-Joystick/
    */
    static boolean gamePaused = false;
    @Override
    public boolean onTouchEvent(MotionEvent event){
        if (event.getAction() != MotionEvent.ACTION_UP ){
            if (gamePaused && event.getX() >= (width/2f)-(textTouchWidth/1.6f) && event.getX() <= (width/2f)+(textQuitWidth/2f) && event.getY() > height * .63f && event.getY() < height * .8f) {
                //Quit
                game.quitting = true;
                touchingScreen = false;
                totalLevelActions.clear();
                currentLevelActions.clear();
                levelObjects = null;
                //Log.i("touchlisten", "quit");
            }
            else if(event.getX() > pauseButtonHitbox && event.getY() > pauseButtonHitbox) {
                //moving
                touchingScreen = true;
                gamePaused = false;
                if(!game.gameRunning) {
                    game.gameRunning = true;
                    game.startSong();
                    //Log.i("touchlisten", touchX + " " + touchY);
                }
                //Log.i("touchlisten", touchX + "XX" + touchY);
                touchX = event.getX();
                touchY = event.getY();
            }
        }
        else {
            if (event.getX() < pauseButtonHitbox && event.getY() < pauseButtonHitbox) {
                //pause
                gamePaused = true;
                game.gameRunning = false;
                game.frameCount--;
                invalidate();
                //Log.i("touchlisten", "pause");
            }
            touchingScreen = false;
        }
        return true;
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if(gameStarted){
            height = canvas.getHeight();
            width = canvas.getWidth();
            borderScaleWidth = width*borderAdditionScale;
            borderScaleWidthMinusWidth = width - borderScaleWidth;
            borderScaleHeight = height*borderAdditionScale;
            borderScaleHeightMinusHeight = height - borderScaleHeight;
            controllerCenterX = (int)(width-(width*.125) - (width*.03));
            controllerCenterY = (int)(height-(height*.225) - (width*.03));
            touchX = controllerCenterX;
            touchY = controllerCenterY;
            controllerMaxRadius=(int)(width-controllerCenterX- (width*.03));
            if(controllerCenterY+controllerMaxRadius>height){
                controllerCenterY=height-controllerMaxRadius;
            }
            maxSpeed = (int)(controllerMaxRadius*0.05);
            // Log.i("controllerInfo",controllerCenterX +" " +controllerCenterY + " " + controllerMaxRadius);

            player.set(0,0, (int)(playerscale*width),(int)(playerscale*width));
            // Log.i("playerscale",playerscale*width + " " + playerscale*width + " " + width + " " + playerscale);
            player.offset(width/2,height/2);
            if(!game.random){
            playerColor.setColor(Levels.totalLevels[game.levelID].getPlayerColor());}
            else{
                playerColor.setColor(Color.argb(255,choose.nextInt(200)+56,choose.nextInt(200)+56,choose.nextInt(200)+56));
            }
            playerColor.setTextSize((100/1920f)*width);
            healthText.set(playerColor);

            pauseCircle = width*.04f;
            pauseRectTop = height*.03f;
            pauseRectBottom = height*.11f;
            pauseText.setColor(Color.WHITE);
            pauseText.setTextSize((100/1920f)*width);

            progressBarColor.set(playerColor);
            progressBarColor.setAlpha(150);
            progressBar.set(0,0,0,(int)(height*.05f));
            if(game.songLoaded){
            progressSpeed= game.song.getDuration()/17f;}

            //Log.i("cloning","start " +Levels.totalLevels[game.levelID].getObjects()[0].getX());
            levelObjects = new gameObject[Levels.totalLevels[game.levelID].getObjects().length];
            totalLevelActions = new ArrayList<>();
            currentLevelActions = new ArrayList<>();
            removedActions = new ArrayList<>();
            for(int i = 0;i < Levels.totalLevels[game.levelID].getObjects().length; i++){//copy objects
                levelObjects[i] = new gameObject(Levels.totalLevels[game.levelID].getObjects()[i].getX(),
                        Levels.totalLevels[game.levelID].getObjects()[i].getY(),
                        Levels.totalLevels[game.levelID].getObjects()[i].getRight(),
                        Levels.totalLevels[game.levelID].getObjects()[i].getBottom(),
                        Levels.totalLevels[game.levelID].getObjects()[i].getDoesDamage(),
                        Levels.totalLevels[game.levelID].getObjects()[i].getisRotating(),
                        Levels.totalLevels[game.levelID].getObjects()[i].getIsSquare(),
                        Levels.totalLevels[game.levelID].getObjects()[i].getAlpha(),
                        Levels.totalLevels[game.levelID].getObjects()[i].getRed(),
                        Levels.totalLevels[game.levelID].getObjects()[i].getGreen(),
                        Levels.totalLevels[game.levelID].getObjects()[i].getBlue(),
                        Levels.totalLevels[game.levelID].getObjects()[i].getRotation());
            }

            for(int i = 0; i <  Levels.totalLevels[game.levelID].getLevelActions().length;i++) {//copy and build actions
                totalLevelActions.add(new objectAction(
                        Levels.totalLevels[game.levelID].getLevelActions()[i].getObjectId(),
                        Levels.totalLevels[game.levelID].getLevelActions()[i].getStartFrame(),
                        Levels.totalLevels[game.levelID].getLevelActions()[i].getDuration(),
                        Levels.totalLevels[game.levelID].getLevelActions()[i].getdX(),
                        Levels.totalLevels[game.levelID].getLevelActions()[i].getdY(),
                        (int)Levels.totalLevels[game.levelID].getLevelActions()[i].getRotationAngle(),
                        Levels.totalLevels[game.levelID].getLevelActions()[i].getactionBoolean(),
                        (int)Levels.totalLevels[game.levelID].getLevelActions()[i].getnewRed(),
                        (int)Levels.totalLevels[game.levelID].getLevelActions()[i].getNewGreen(),
                        (int)Levels.totalLevels[game.levelID].getLevelActions()[i].getNewBlue(),
                        Levels.totalLevels[game.levelID].getLevelActions()[i].getEndX(),
                        Levels.totalLevels[game.levelID].getLevelActions()[i].getEndY(),
                        Levels.totalLevels[game.levelID].getLevelActions()[i].getType()));
                totalLevelActions.get(i).buildAction();
            }

                //build objects
                for (int i = 0; i < levelObjects.length; i++) {
                    if (levelObjects[i].getIsSquare()) {
                        levelObjects[i].updateShape(levelObjects[i].getRight() * width, levelObjects[i].getRight() * width);
                    }
                    else {
                        levelObjects[i].updateShape(levelObjects[i].getRight() * width, levelObjects[i].getBottom() * height);
                    }
                    levelObjects[i].updateCoordinates(levelObjects[i].getX() * width, levelObjects[i].getY() * height);
                }

           // Log.i("cloning","end " +Levels.totalLevels[game.levelID].getObjects()[0].getX() + " " + levelObjects[0].getX());

            if(!game.random){
                mainRed = (int)levelObjects[0].getRed();
                mainBlue=(int)levelObjects[0].getBlue();
                mainGreen=(int)levelObjects[0].getGreen();
            }
            else{
                mainRed = choose.nextInt(200)+56;
                mainBlue= choose.nextInt(200)+56;
                mainGreen= choose.nextInt(200)+56;
            }
             //Log.i("gotLevel","gotLevels? " + levelObjects[0].getX());

            screenShaking=false;
            gamePaused=false;
            doneAddingActions=false;
            touchingScreen=false;
            gameStarted = false;

            titleTextX=-playerColor.measureText(Levels.totalLevels[game.levelID].getTitle());
            titleTextY=height*.25f;
            titleSpeed = -titleTextX/30f;
            titleText.set(playerColor);
             textPausedWidth = pauseText.measureText("PAUSED");
             textTouchWidth = pauseText.measureText("TOUCH TO CONTINUE");
             textQuitWidth = pauseText.measureText("QUIT");
        }
        render(canvas);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public void render(android.graphics.Canvas canvas){
        //move player
        updatePlayer();

        if(!game.random) { //adding actions
            doneAddingActions = true;
            while (doneAddingActions) {
                if (!totalLevelActions.isEmpty()) {
                    if (totalLevelActions.get(0).getStartFrame() <= game.frameCount) {
                        currentLevelActions.add(totalLevelActions.get(0));
                        totalLevelActions.remove(0);
                        //Log.i("actionadd", "addedSomething "+currentLevelActions.get(currentLevelActions.size()-1).getObjectId() + " " + totalLevelActions.size());
                    } else {
                        doneAddingActions = false;
                    }
                } else {
                    doneAddingActions = false;
                }
            }
        }
        else {//random actions
            randomAction();
        }

        //do actions
        try {
            for (objectAction action : currentLevelActions) {
                action.doAction();
                //Log.i("actiondo","didaction " + action.getObjectId());
                if (action.getCurrentFrame() > action.getDuration()) {
                    removedActions.add(action);
                }
            }
            currentLevelActions.removeAll(removedActions);
            removedActions.clear();
        } catch (Exception ignored) {}

        //ScreenShake
        if(screenShaking){
            canvas.save();
            canvas.translate(screenShake[choose.nextInt(2)],screenShake[choose.nextInt(2)]);
        }

        if(immunityFrames<game.frameCount){
            damaged=false;
        }

        if(damaged && game.frameCount%8>=4){
            playerColor.setAlpha(0);
        }
        else {
            if(playerColor.getAlpha()==0)
                playerColor.setAlpha(255);
        }

        //draw player
        canvas.save();
        canvas.rotate((float)touchDir,player.centerX(),player.centerY());
        canvas.drawRect(player, playerColor);
        canvas.restore();

        //drawing objects
        for (gameObject levelObject : levelObjects) {
            int x = (int)(levelObject.getX());
            int y = (int)(levelObject.getY());
            currentObject.set(x, y, (int) ((levelObject.getRight()) + x), (int) ((levelObject.getBottom()) + y));
            if(levelObject.getRotation()!=0) {
                canvas.save();
                canvas.rotate((int) levelObject.getRotation(), levelObject.getRotationOriginX(), levelObject.getRotationOriginY());
                canvas.drawRect(currentObject, levelObject.getobjectColor());
                canvas.restore();
            }
            else{
                canvas.drawRect(currentObject, levelObject.getobjectColor());
            }

            if (!damaged && levelObject.getDoesDamage() && currentObject.intersect(player)) {
                immunityFrames = (int)game.frameCount + 180;
                damaged=true;
                game.damaged();
                //Log.i("damaged","hit " + game.frameCount);
            }
        }

        if(screenShaking){
            canvas.restore();
           }

        //joystick
        canvas.drawCircle(controllerCenterX,controllerCenterY,controllerMaxRadius,controllerColor);

        if(!game.random) {//progress bar
            progressBar.set(0, 0, (int) (width * 1.03 * (game.frameCount / progressSpeed)), (int) (height * .05f));
            canvas.drawRect(progressBar, progressBarColor);
        }
        else{//time
            canvas.drawText("Time: " + (int)((game.frameCount)/(1000/17)) + "s",width*.5f,height*.1f,healthText);
        }

        //pause button
        canvas.drawCircle(pauseCircle,pauseCircle,pauseCircle,controllerColor);
        canvas.drawRect(width*.02f,pauseRectTop,width*.035f,pauseRectBottom,pauseButton);
        canvas.drawRect(width*.045f,pauseRectTop,width*.06f,pauseRectBottom,pauseButton);

        //health
        canvas.drawText("" + game.playerHealth,width*.95f,height*.1f,healthText);

        //Paused
        if(gamePaused){
            canvas.drawRect((width/2f)-(textQuitWidth/1.6f),height*.63f,(textTouchWidth/2f)+(width/3f),height*.8f,controllerColor);//quit
            canvas.drawRect(width*.2f,height*.3f,width*.85f,height*.8f,controllerColor);//box
            canvas.drawText("PAUSED",(width/2f)-(textPausedWidth/2f),height*.4f,pauseText);
            canvas.drawText("TOUCH TO CONTINUE",(width/2f)-(textTouchWidth/2f),height*.6f,pauseText);
            canvas.drawText("QUIT",(width/2f)-(textQuitWidth/2f),height*.75f,pauseText);
        }

        if(game.frameCount<260){//titleText at beginning
            canvas.drawText(Levels.totalLevels[game.levelID].getTitle(), titleTextX,titleTextY,titleText);
            if(game.frameCount >200){
                titleTextX -= titleSpeed;
            }
            else if(game.frameCount < 100 && game.frameCount > 68){
                titleTextX += titleSpeed;
            }
        }
        //Log.i("cloning","end " +Levels.totalLevels[game.levelID].getObjects()[0].getX() + " " + levelObjects[0].getX() + " f: " +Levels.totalLevels[game.levelID].getLevelActions()[0].getStartFrame());
    }

    public void randomAction(){
        if (choose.nextInt(100) <= 5) {
            randomType = actionType.values()[choose.nextInt(actionType.values().length)];
            randomId=choose.nextInt(levelObjects.length-1);

            if(!levelObjects[randomId].getisRotating()){
                levelObjects[randomId].updateDoesDamage(true); }

            switch(randomType){
                case SCREENSHAKE:
                    random = choose.nextInt(21);
                    randomdX=choose.nextFloat();
                    randomdY=choose.nextFloat();
                    randomEndX=choose.nextFloat();
                    randomEndY = choose.nextFloat();
                    break;

                case RESET:
                case NEWSHAPE:
                    random=choose.nextInt(207)+50;
                    randomdX=Math.abs(choose.nextFloat()/2.5f);
                    randomdY=Math.abs(choose.nextFloat()/2.5f);
                    randomEndX = -choose.nextFloat();
                    randomEndY = -choose.nextFloat();
                    //Log.i("random",randomdX + " " + randomdY);
                    break;

                case ROTATE:
                    randomdX=choose.nextFloat();
                    randomdY=choose.nextFloat();
                    randomEndX = randomdX+(((float)choose.nextInt(2)/10)-0.1f);
                    randomEndY = randomdY+(((float)choose.nextInt(2)/10)-0.1f);
                    levelObjects[randomId].updateDoesDamage(false);
                    break;

                default:
                    random = choose.nextInt(207)+50;
                    randomdX=choose.nextFloat();
                    randomdY=choose.nextFloat();
                    randomEndX=choose.nextFloat();
                    randomEndY = choose.nextFloat();
                    break;
            }
            //Log.i("random",choose.nextFloat() + "");
            objectAction randomAction = new objectAction(
                    choose.nextInt(levelObjects.length-1),
                    (int)game.frameCount,
                    choose.nextInt(280)+20,
                    randomdX,
                    randomdY,
                    choose.nextInt(720),
                    choose.nextBoolean(),
                    random,
                    choose.nextInt(256),
                    choose.nextInt(256),
                    randomEndX,
                    randomEndY,
                    randomType);
            randomAction.buildAction();
            currentLevelActions.add(randomAction);

        }
    }

    /*  joystick modified
        https://www.instructables.com/id/A-Simple-Android-UI-Joystick/
     */
    public void updatePlayer(){
        new Thread() {
            @Override
            public void run(){
                if(touchingScreen) {
                    touchDir = Math.atan2(touchY - controllerCenterY, touchX - controllerCenterX) * (180 / Math.PI);
                    touchRadius = (int) Math.sqrt(Math.pow(touchX - controllerCenterX, 2) + Math.pow(touchY - controllerCenterY, 2));

                    //  Log.i("touchdir", touchDir + " " + touchRadius + " " + controllerMaxRadius);
                    try {
                        ratio = ((controllerMaxRadius / touchRadius) * -0.03) -.04;
                    }
                    catch (ArithmeticException e){ratio = 0;}

                    disX =  ((controllerCenterX - touchX) * ratio);
                    if(disX < -maxSpeed)
                        disX = -maxSpeed;
                    else if(disX > maxSpeed)
                        disX = maxSpeed;

                    disY =  ((controllerCenterY - touchY) * ratio);
                    if(disY < -maxSpeed)
                        disY = -maxSpeed;
                    else if(disY > maxSpeed)
                        disY = maxSpeed;

                    posTryX = disX + player.centerX();
                    posTryY = disY + player.centerY();
                    if (posTryX < borderScaleWidthMinusWidth && posTryX > borderScaleWidth) {
                        player.offset((int)disX, 0);
                    }

                    if (posTryY < borderScaleHeightMinusHeight && posTryY > borderScaleHeight) {
                        player.offset(0, (int)disY);
                    }
                    // Log.i("displacepos", disX + " y: " + disY + " " + ratio);
                }
            }
        }.start();
    }

}
