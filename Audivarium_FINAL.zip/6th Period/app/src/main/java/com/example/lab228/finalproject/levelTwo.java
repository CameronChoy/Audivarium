package com.example.lab228.finalproject;

public class levelTwo {
    static float normalScale = 100 / 1920f;
    static gameObject[] levelObjects = {
            new gameObject(1.36f,0.2f,.05f,.1f,false,false,true,150,214, 57, 57,0),//0
            new gameObject(1.32f,0.5f,.05f,.1f,false,false,true,150,214, 57, 57,0),//1
            new gameObject(1.24f,0.9f,.05f,.1f,false,false,true,150,214, 57, 57,0),//2
            new gameObject(1.52f,0.1f,.05f,.1f,false,false,true,150,214, 57, 57,0),//3
            new gameObject(1.48f,0.6f,.05f,.1f,false,false,true,150,214, 57, 57,0),//4
            new gameObject(1.17f,0.58f,.05f,.1f,false,false,true,150,214, 57, 57,0),//5
            new gameObject(1.58f,0.3f,.05f,.1f,false,false,true,150,214, 57, 57,0),//6
            new gameObject(1.62f,0.65f,.05f,.1f,false,false,true,150,214, 57, 57,0),//7
            new gameObject(1.23f,0f,.05f,.1f,false,false,true,150,214, 57, 57,0),//8
            new gameObject(1.87f,0.2f,.05f,.1f,false,false,true,150,214, 57, 57,0),//9
            new gameObject(1.47f,0.5f,.2f,.05f,true,false,false,255,214, 57, 57,0),//10
            new gameObject(1.52f,0.8f,.2f,.05f,true,false,false,255,214, 57, 57,0),//11
            new gameObject(1.6f,0.1f,.2f,.05f,true,false,false,255,214, 57, 57,0),//12
            new gameObject(1.2f,0.6f,.2f,.05f,true,false,false,255,214, 57, 57,0),//13
            new gameObject(1.4f,0.58f,.2f,.05f,true,false,false,255,214, 57, 57,0),//14
            new gameObject(1.8f,0.3f,.2f,.05f,true,false,false,255,214, 57, 57,0),//15
            new gameObject(1.08f,0.65f,.2f,.05f,true,false,false,255,214, 57, 57,0),//16
            new gameObject(1.75f,0.78f,.2f,.05f,true,false,false,255,214, 57, 57,0),//17
            new gameObject(1.4f,0f,.2f,.05f,true,false,false,255,214, 57, 57,0),//18
            new gameObject(1.25f,0f,.2f,.05f,true,false,false,255,214, 57, 57,0),//19
            new gameObject(1.95f,0f,.07f,2f,true,false,true,255,214, 57, 57,0),//20
            new gameObject(1.75f,0.8f,.07f,normalScale,true,false,true,255,214, 57, 57,0),//21
            new gameObject(1.75f,0.8f,.07f,normalScale,true,false,true,255,214, 57, 57,0),//22
            new gameObject(1.75f,0.8f,.07f,normalScale,true,false,true,255,214, 57, 57,0),//23
            new gameObject(1.75f,0.8f,.07f,normalScale,true,false,true,255,214, 57, 57,0),//24
            new gameObject(1.75f,0.8f,.07f,normalScale,true,false,true,255,214, 57, 57,0),//25
            new gameObject(1.75f,0.8f,.07f,normalScale,true,false,true,255,214, 57, 57,0),//26
            new gameObject(1.75f,0.8f,.07f,normalScale,true,false,true,255,214, 57, 57,0),//27
            new gameObject(1.75f,0.8f,.07f,normalScale,true,false,true,255,214, 57, 57,0),//28
            new gameObject(1.75f,0.8f,.07f,normalScale,true,false,true,255,214, 57, 57,0),//29
            new gameObject(1.75f,0.8f,.07f,normalScale,true,false,true,255,214, 57, 57,0),//30
            new gameObject(1.75f,0.8f,.07f,normalScale,true,false,true,255,214, 57, 57,0),//31
            new gameObject(1.75f,0.8f,.07f,normalScale,true,false,true,255,214, 57, 57,0),//32
            new gameObject(1.75f,0.8f,.07f,normalScale,true,false,true,255,214, 57, 57,0),//33
            new gameObject(1.75f,0.8f,.07f,normalScale,true,false,true,255,214, 57, 57,0),//34
            new gameObject(1.75f,0.8f,.07f,normalScale,true,false,true,255,214, 57, 57,0),//35
            new gameObject(1.75f,0.8f,.07f,normalScale,true,false,true,255,214, 57, 57,0),//36
            new gameObject(1.75f,0.8f,.07f,normalScale,true,false,true,255,214, 57, 57,0),//37
            new gameObject(1.75f,0.8f,.07f,normalScale,true,false,true,255,214, 57, 57,0),//38
            new gameObject(1.75f,0.8f,.07f,normalScale,true,false,true,255,214, 57, 57,0),//39
            new gameObject(1.75f,0.8f,.07f,normalScale,true,false,true,255,214, 57, 57,0),//40
    };

    static objectAction[] levelActions = {
            new objectAction(0,22,80,-2f,10f,0,false,2,0,0,0,0,actionType.SCREENSHAKE),
            new objectAction(0,22,90,-2f,10f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(1,22,90,-2f,10f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(2,22,90,-2f,10f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(3,22,90,-2f,10f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(4,22,90,-2f,10f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(5,22,90,-2f,10f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(6,22,90,-2f,10f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(7,22,90,-2f,10f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(8,22,90,-2f,10f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(9,22,90,-2f,10f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(10,40,250,-2f,10f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(11,40,250,-2f,10f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(12,40,250,-2f,10f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(13,40,250,-2f,10f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(14,40,250,-2f,10f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(15,40,250,-2f,10f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(16,40,250,-2f,10f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(17,40,250,-2f,10f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(18,40,250,-2f,10f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(19,40,250,-2f,10f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(20,183,1,0f,0f,0,true,0,0,0,0,0,actionType.EXPLODEIN),
            new objectAction(21,188,1,0f,0f,0,true,0,0,0,0,0,actionType.EXPLODEIN),
            new objectAction(22,193,1,0f,0f,0,true,0,0,0,0,0,actionType.EXPLODEIN),
            new objectAction(23,198,1,0f,0f,0,true,0,0,0,0,0,actionType.EXPLODEIN),
            new objectAction(24,203,1,0f,0f,0,true,0,0,0,0,0,actionType.EXPLODEIN),
            new objectAction(25,208,1,0f,0f,0,true,0,0,0,0,0,actionType.EXPLODEIN),
            new objectAction(26,213,1,0f,0f,0,true,0,0,0,0,0,actionType.EXPLODEIN),
            new objectAction(0,325,1,.02f,.25f,255,true,0,0,0,.79f,1.18f,actionType.NEWSHAPE),
            new objectAction(1,326,1,.02f,.25f,255,true,0,0,0,.43f,1.5f,actionType.NEWSHAPE),
            new objectAction(2,327,1,.02f,.25f,255,true,0,0,0,.14f,1.86f,actionType.NEWSHAPE),
            new objectAction(3,328,1,.02f,.25f,255,true,0,0,0,0f,1.41f,actionType.NEWSHAPE),
            new objectAction(4,329,1,.02f,.25f,255,true,0,0,0,.24f,1.57f,actionType.NEWSHAPE),
            new objectAction(5,330,1,.02f,.25f,255,true,0,0,0,.37f,1.17f,actionType.NEWSHAPE),
            new objectAction(6,331,1,.02f,.25f,255,true,0,0,0,.55f,1.23f,actionType.NEWSHAPE),
            new objectAction(7,332,1,.02f,.25f,255,true,0,0,0,.76f,1.68f,actionType.NEWSHAPE),
            new objectAction(8,333,1,.02f,.25f,255,true,0,0,0,.81f,1.77f,actionType.NEWSHAPE),
            new objectAction(9,334,1,.02f,.25f,255,true,0,0,0,.98f,1.85f,actionType.NEWSHAPE),
            new objectAction(0,345,80,-2f,10f,0,false,2,0,0,0,0,actionType.SCREENSHAKE),
            new objectAction(20,345,180,10f,-2f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(21,345,180,10f,-2f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(22,345,180,10f,-2f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(23,345,180,10f,-2f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(24,345,180,10f,-2f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(25,345,180,10f,-2f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(26,345,180,10f,-2f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(0,345,300,10f,-2.1f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(1,345,300,10f,-2.1f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(2,345,300,10f,-2.1f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(3,345,300,10f,-2.1f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(4,345,300,10f,-2.1f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(5,345,300,10f,-2.1f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(6,345,300,10f,-2.1f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(7,345,300,10f,-2.1f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(8,345,300,10f,-2.1f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(9,345,300,10f,-2.1f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(20,579,1,0f,0f,0,true,0,0,0,0,0,actionType.EXPLODEIN),
            new objectAction(21,609,1,0f,0f,0,true,0,0,0,0,0,actionType.EXPLODEIN),
            new objectAction(22,639,1,0f,0f,0,true,0,0,0,0,0,actionType.EXPLODEIN),
            new objectAction(23,669,1,0f,0f,0,true,0,0,0,0,0,actionType.EXPLODEIN),
            new objectAction(24,699,1,0f,0f,0,true,0,0,0,0,0,actionType.EXPLODEIN),
            new objectAction(25,729,1,0f,0f,0,true,0,0,0,0,0,actionType.EXPLODEIN),
            new objectAction(26,759,1,0f,0f,0,true,0,0,0,0,0,actionType.EXPLODEIN),
            new objectAction(0,760,1,.07f,0,0,true,1,0,0,-.5f,0,actionType.NEWSHAPE),
            new objectAction(1,761,1,.07f,0,0,true,1,0,0,-.5f,0,actionType.NEWSHAPE),
            new objectAction(2,762,1,.07f,0,0,true,1,0,0,-.5f,0,actionType.NEWSHAPE),
            new objectAction(0,789,1,0f,0f,0,true,0,0,0,0,0,actionType.EXPLODEIN),
            new objectAction(1,819,1,0f,0f,0,true,0,0,0,0,0,actionType.EXPLODEIN),
            new objectAction(2,849,1,0f,0f,0,true,0,0,0,0,0,actionType.EXPLODEIN),

            new objectAction(3,850,1,.07f,0,0,true,1,0,0,-.5f,0,actionType.NEWSHAPE),
            new objectAction(4,850,1,.07f,0,0,true,1,0,0,-.5f,0,actionType.NEWSHAPE),
            new objectAction(5,850,1,.07f,0,0,true,1,0,0,-.5f,0,actionType.NEWSHAPE),
            new objectAction(6,850,1,.07f,0,0,true,1,0,0,-.5f,0,actionType.NEWSHAPE),
            new objectAction(7,850,1,.07f,0,0,true,1,0,0,-.5f,0,actionType.NEWSHAPE),
            new objectAction(8,850,1,.07f,0,0,true,1,0,0,-.5f,0,actionType.NEWSHAPE),
            new objectAction(9,850,1,.07f,0,0,true,1,0,0,-.5f,0,actionType.NEWSHAPE),
            new objectAction(10,850,1,.07f,0,0,true,1,0,0,-.5f,0,actionType.NEWSHAPE),

            new objectAction(3,924,1,0f,0f,0,true,0,0,0,0,0,actionType.EXPLODEIN),
            new objectAction(4,942,1,0f,0f,0,true,0,0,0,0,0,actionType.EXPLODEIN),
            new objectAction(5,963,1,0f,0f,0,true,0,0,0,0,0,actionType.EXPLODEIN),
            new objectAction(6,983,1,0f,0f,0,true,0,0,0,0,0,actionType.EXPLODEIN),

            new objectAction(20,992,1,0f,0f,0,true,0,0,0,0,2f,actionType.EXPLODEOUT),
            new objectAction(21,992,1,0f,0f,0,true,0,0,0,0,2f,actionType.EXPLODEOUT),
            new objectAction(22,992,1,0f,0f,0,true,0,0,0,0,2f,actionType.EXPLODEOUT),
            new objectAction(23,992,1,0f,0f,0,true,0,0,0,0,2f,actionType.EXPLODEOUT),
            new objectAction(24,992,1,0f,0f,0,true,0,0,0,0,2f,actionType.EXPLODEOUT),
            new objectAction(25,992,1,0f,0f,0,true,0,0,0,0,2f,actionType.EXPLODEOUT),
            new objectAction(26,992,1,0f,0f,0,true,0,0,0,0,2f,actionType.EXPLODEOUT),
            new objectAction(0,992,1,0f,0f,0,true,0,0,0,0,2f,actionType.EXPLODEOUT),
            new objectAction(1,992,1,0f,0f,0,true,0,0,0,0,2f,actionType.EXPLODEOUT),
            new objectAction(2,992,1,0f,0f,0,true,0,0,0,0,2f,actionType.EXPLODEOUT),

            new objectAction(7,1004,1,0f,0f,0,true,0,0,0,0,0,actionType.EXPLODEIN),
            new objectAction(8,1022,1,0f,0f,0,true,0,0,0,0,0,actionType.EXPLODEIN),
            new objectAction(9,1043,1,0f,0f,0,true,0,0,0,0,0,actionType.EXPLODEIN),
            new objectAction(10,1063,1,0f,0f,0,true,0,0,0,0,0,actionType.EXPLODEIN),
            new objectAction(3,1050,125,10f,-2.5f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(4,1070,125,2.5f,10f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(5,1090,125,10f,2.5f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(6,1110,125,-2.5f,10f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(7,1130,125,10f,-2.5f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(8,1150,125,2.5f,10f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(9,1170,125,10f,2.5f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(10,1190,125,-2.5f,10f,0,false,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(11,1200,1,.1f,.5f,255,true,0,0,0,0f,-.5f,actionType.NEWSHAPE),
            new objectAction(12,1200,1,.1f,.5f,255,true,0,0,0,.1f,-.5f,actionType.NEWSHAPE),
            new objectAction(13,1200,1,.1f,.5f,255,true,0,0,0,.2f,-.5f,actionType.NEWSHAPE),
            new objectAction(14,1200,1,.1f,.5f,255,true,0,0,0,.3f,-.5f,actionType.NEWSHAPE),
            new objectAction(15,1200,1,.1f,.5f,255,true,0,0,0,.4f,-.5f,actionType.NEWSHAPE),
            new objectAction(16,1200,1,.1f,.5f,255,true,0,0,0,.5f,-.5f,actionType.NEWSHAPE),
            new objectAction(17,1200,1,.1f,.5f,255,true,0,0,0,.6f,-.5f,actionType.NEWSHAPE),
            new objectAction(18,1200,1,.1f,.5f,255,true,0,0,0,.7f,-.5f,actionType.NEWSHAPE),
            new objectAction(19,1200,1,.1f,.5f,255,true,0,0,0,.8f,-.5f,actionType.NEWSHAPE),
            new objectAction(20,1200,1,.1f,.5f,255,true,0,0,0,.9f,-.5f,actionType.NEWSHAPE),
            new objectAction(21,1200,1,.1f,.5f,255,true,0,0,0,1f,-.5f,actionType.NEWSHAPE),

            new objectAction(22,1202,1,.1f,.5f,255,true,0,0,0,.0f,1.1f,actionType.NEWSHAPE),
            new objectAction(23,1202,1,.1f,.5f,255,true,0,0,0,.1f,1.1f,actionType.NEWSHAPE),
            new objectAction(24,1202,1,.1f,.5f,255,true,0,0,0,.2f,1.1f,actionType.NEWSHAPE),
            new objectAction(25,1202,1,.1f,.5f,255,true,0,0,0,.3f,1.1f,actionType.NEWSHAPE),
            new objectAction(26,1202,1,.1f,.5f,255,true,0,0,0,.4f,1.1f,actionType.NEWSHAPE),
            new objectAction(27,1202,1,.1f,.5f,255,true,0,0,0,.5f,1.1f,actionType.NEWSHAPE),
            new objectAction(28,1202,1,.1f,.5f,255,true,0,0,0,.6f,1.1f,actionType.NEWSHAPE),
            new objectAction(29,1202,1,.1f,.5f,255,true,0,0,0,.7f,1.1f,actionType.NEWSHAPE),
            new objectAction(30,1202,1,.1f,.5f,255,true,0,0,0,.8f,1.1f,actionType.NEWSHAPE),
            new objectAction(31,1202,1,.1f,.5f,255,true,0,0,0,.9f,1.1f,actionType.NEWSHAPE),
            new objectAction(32,1202,1,.1f,.5f,255,true,0,0,0,1f,1.1f,actionType.NEWSHAPE),

            new objectAction(11,1203,1,.1f,.5f,255,true,7, 164, 255,0f,-.5f,actionType.NEWCOLOR),
            new objectAction(12,1203,1,.1f,.5f,255,true,7, 164, 255,.1f,-.5f,actionType.NEWCOLOR),
            new objectAction(13,1203,1,.1f,.5f,255,true,7, 164, 255,.2f,-.5f,actionType.NEWCOLOR),
            new objectAction(14,1203,1,.1f,.5f,255,true,7, 164, 255,.3f,-.5f,actionType.NEWCOLOR),
            new objectAction(15,1203,1,.1f,.5f,255,true,7, 164, 255,.4f,-.5f,actionType.NEWCOLOR),
            new objectAction(16,1203,1,.1f,.5f,255,true,7, 164, 255,.5f,-.5f,actionType.NEWCOLOR),
            new objectAction(17,1203,1,.1f,.5f,255,true,7, 164, 255,.6f,-.5f,actionType.NEWCOLOR),
            new objectAction(18,1203,1,.1f,.5f,255,true,7, 164, 255,.7f,-.5f,actionType.NEWCOLOR),
            new objectAction(19,1203,1,.1f,.5f,255,true,7, 164, 255,.8f,-.5f,actionType.NEWCOLOR),
            new objectAction(20,1203,1,.1f,.5f,255,true,7, 164, 255,.9f,-.5f,actionType.NEWCOLOR),
            new objectAction(21,1203,1,.1f,.5f,255,true,7, 164, 255,1f,-.5f,actionType.NEWCOLOR),

            new objectAction(22,1204,1,.1f,.5f,255,true,7, 164, 255,.0f,1.1f,actionType.NEWCOLOR),
            new objectAction(23,1204,1,.1f,.5f,255,true,7, 164, 255,.1f,1.1f,actionType.NEWCOLOR),
            new objectAction(24,1204,1,.1f,.5f,255,true,7, 164, 255,.2f,1.1f,actionType.NEWCOLOR),
            new objectAction(25,1204,1,.1f,.5f,255,true,7, 164, 255,.3f,1.1f,actionType.NEWCOLOR),
            new objectAction(26,1204,1,.1f,.5f,255,true,7, 164, 255,.4f,1.1f,actionType.NEWCOLOR),
            new objectAction(27,1204,1,.1f,.5f,255,true,7, 164, 255,.5f,1.1f,actionType.NEWCOLOR),
            new objectAction(28,1204,1,.1f,.5f,255,true,7, 164, 255,.6f,1.1f,actionType.NEWCOLOR),
            new objectAction(29,1204,1,.1f,.5f,255,true,7, 164, 255,.7f,1.1f,actionType.NEWCOLOR),
            new objectAction(30,1204,1,.1f,.5f,255,true,7, 164, 255,.8f,1.1f,actionType.NEWCOLOR),
            new objectAction(31,1204,1,.1f,.5f,255,true,7, 164, 255,.9f,1.1f,actionType.NEWCOLOR),
            new objectAction(32,1204,1,.1f,.5f,255,true,7, 164, 255,1f,1.1f,actionType.NEWCOLOR),

            new objectAction(33,1240,1,1.3f,.25f,0,false,0,0,0,-.1f,0f,actionType.NEWSHAPE),
            new objectAction(34,1240,1,1.3f,.25f,0,false,0,0,0,-.1f,.82f,actionType.NEWSHAPE),
            new objectAction(33,1240,60,0f,.35f,60,true,0,0,0,0f,0f,actionType.NEWALPHA),
            new objectAction(34,1240,60,0f,.35f,60,true,0,0,0,0f,0f,actionType.NEWALPHA),

            new objectAction(0,1240,1,.15f,0f,0,true,1,0,0,-.1f,0f,actionType.NEWSHAPE),
            new objectAction(1,1240,1,.15f,0f,0,true,1,0,0,-.1f,0f,actionType.NEWSHAPE),
            new objectAction(2,1240,1,.15f,0f,0,true,1,0,0,-.1f,0f,actionType.NEWSHAPE),
            new objectAction(3,1240,1,.15f,0f,0,true,1,0,0,-.1f,0f,actionType.NEWSHAPE),
            new objectAction(4,1240,1,.15f,0f,0,true,1,0,0,-.1f,0f,actionType.NEWSHAPE),
            new objectAction(0,1262,1,.25f,0f,0,true,0,0,0,0,0,actionType.EXPLODEIN),
            new objectAction(1,1262,1,.85f,0f,0,true,0,0,0,0,0,actionType.EXPLODEIN),
            new objectAction(2,1288,1,0f,.5f,0,true,0,0,0,0,0,actionType.EXPLODEIN),
            new objectAction(3,1296,1,0f,.8f,0,true,0,0,0,0,0,actionType.EXPLODEIN),
            new objectAction(4,1296,1,0f,.25f,0,true,0,0,0,0,0,actionType.EXPLODEIN),

            new objectAction(11,1306-2,15,10f,-.15f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(32,1306-2,15,10f,.65f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(12,1312-2,15,10f,-.15f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(31,1312-2,15,10f,.65f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(13,1318-2,15,10f,-.15f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(30,1318-2,15,10f,.65f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(11,1336-18,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(32,1336-18,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(14,1324-2,15,10f,-.15f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(29,1324-2,15,10f,.65f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(12,1342-18,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(31,1342-18,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(15,1330-2,15,10f,-.15f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(28,1330-2,15,10f,.65f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(13,1348-18,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(30,1348-18,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(16,1336-2,15,10f,-.15f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(27,1336-2,15,10f,.65f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(14,1354-18,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(29,1354-18,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(17,1342-2,15,10f,-.15f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(26,1342-2,15,10f,.65f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(15,1360-18,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(28,1360-18,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(5,1346,1,.25f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(18,1348-2,15,10f,-.15f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(25,1348-2,15,10f,.65f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(16,1366-18,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(27,1366-18,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(19,1354-2,15,10f,-.15f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(24,1354-2,15,10f,.65f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(17,1372-18,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(26,1372-18,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(20,1360-2,15,10f,-.15f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(23,1360-2,15,10f,.65f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(18,1378-18,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(25,1378-18,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(6,1361,1,0f,.25f,0,false,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(21,1366-2,15,10f,-.15f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(22,1366-2,15,10f,.65f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(19,1384-18,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(24,1384-18,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(7,1376,1,.5f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(20,1390-18,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(23,1390-18,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(21,1396-18,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(22,1396-18,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(8,1391,1,0f,.75f,0,false,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(9,1400,1,.75f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(0,1400,1,.25f,0f,0,true,0,0,0,-.1f,0,actionType.EXPLODEOUT),
            new objectAction(1,1400,1,.85f,0f,0,true,0,0,0,-.1f,0,actionType.EXPLODEOUT),
            new objectAction(2,1420,1,0f,.5f,0,true,0,0,0,-.1f,0,actionType.EXPLODEOUT),
            new objectAction(3,1440,1,0f,.8f,0,true,0,0,0,-.1f,0,actionType.EXPLODEOUT),
            new objectAction(4,1440,1,0f,.25f,0,true,0,0,0,-.1f,0,actionType.EXPLODEOUT),

            new objectAction(33,1450,1,1.3f,.25f,0,false,0,0,0,-.1f,0f,actionType.NEWSHAPE),
            new objectAction(34,1450,1,1.3f,.25f,0,false,0,0,0,-.1f,.82f,actionType.NEWSHAPE),
            new objectAction(33,1450,60,0f,.35f,60,true,0,0,0,0f,0f,actionType.NEWALPHA),
            new objectAction(34,1450,60,0f,.35f,60,true,0,0,0,0f,0f,actionType.NEWALPHA),
            new objectAction(35,1450,1,.5f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(36,1480,1,0f,.3f,0,false,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(37,1490,1,0f,.75f,0,false,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(21,1635,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(22,1635,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(20,1642,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(23,1642,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(19,1648,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(24,1648,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(21,1654,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(22,1654,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(18,1660,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(25,1660,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(20,1666,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(23,1666,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(5,1678,1,0f,.25f,0,false,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(17,1672,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(26,1672,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(19,1678,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(24,1678,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(6,1678,1,.5f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(16,1684,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(27,1684,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(7,1688,1,0f,.75f,0,false,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(18,1690,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(25,1690,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(15,1696,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(28,1696,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(8,1698,1,.75f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(17,1702,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(26,1702,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(14,1708,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(29,1708,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(9,1708,1,.25f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(16,1714,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(27,1714,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(13,1720,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(30,1720,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(15,1726,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(28,1726,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(12,1732,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(31,1732,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(14,1738,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(29,1738,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(11,1744,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(32,1744,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(13,1750,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(30,1750,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(12,1756,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(31,1756,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(11,1762,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(32,1762,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(33,1770,1,1.3f,.25f,0,false,0,0,0,-.1f,0f,actionType.NEWSHAPE),
            new objectAction(34,1770,1,1.3f,.25f,0,false,0,0,0,-.1f,.82f,actionType.NEWSHAPE),
            new objectAction(33,1450,60,0f,.35f,60,true,0,0,0,0f,0f,actionType.NEWALPHA),
            new objectAction(34,1450,60,0f,.35f,60,true,0,0,0,0f,0f,actionType.NEWALPHA),

            new objectAction(0,1856,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(1,1876,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(2,1896,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(3,1916,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(4,1936,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(12,1936,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(31,1936,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(12,1955,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(31,1955,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(5,1956,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(6,1976,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(11,1976,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(32,1976,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(11,1995,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(32,1995,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(7,1996,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(8,2016,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(15,2017,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(27,2017,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(15,2035,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(27,2035,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(9,2036,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(10,2056,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(0,2076,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(13,2077,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(24,2077,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(13,2095,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(24,2095,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(1,2096,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(2,2116,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(14,2117,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(27,2117,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(14,2135,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(27,2135,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(3,2136,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(4,2156,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(16,2157,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(30,2157,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(16,2175,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(30,2175,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(5,2176,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(6,2196,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(17,2197,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(29,2197,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(17,2215,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(29,2215,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(7,2216,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(8,2236,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(18,2237,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(28,2237,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(18,2255,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(28,2255,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(9,2256,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(10,2276,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(15,2277,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(22,2277,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(15,2295,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(22,2295,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(0,2296,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(1,2316,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(2,2336,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(12,2337,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(31,2337,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(12,2355,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(31,2355,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(3,2356,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(4,2376,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(17,2277,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(25,2377,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(17,2395,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(25,2395,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(5,2396,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(6,2416,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(19,2415,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(26,2415,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(19,2435,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(26,2435,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(7,2436,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(8,2456,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(9,2476,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(11,2477,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(24,2477,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(11,2495,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(24,2495,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(10,2496,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(0,2516,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(1,2536,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(2,2556,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(3,2576,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(4,2596,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(16,2597,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(27,2597,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(16,2614,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(27,2614,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(5,2616,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(17,2617,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(15,2617,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(28,2617,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(26,2617,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(17,2632,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(15,2632,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(28,2632,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(26,2632,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(6,2636,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(18,2637,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(14,2637,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(29,2637,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(25,2637,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(18,2652,15,10f,-.77f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(14,2652,15,10f,-.77f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(29,2652,15,10f,1.37f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(25,2652,15,10f,1.37f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(7,2656,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(19,2657,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(13,2657,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(30,2657,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(24,2657,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(19,2672,15,10f,-.79f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(13,2672,15,10f,-.79f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(30,2672,15,10f,1.39f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(24,2672,15,10f,1.39f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(14,2676,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(20,2677,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(12,2677,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(31,2677,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(23,2677,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(20,2692,15,10f,-.79f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(12,2692,15,10f,-.79f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(31,2692,15,10f,1.39f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(23,2692,15,10f,1.39f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(18,2696,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(21,2697,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(11,2697,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(32,2697,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(22,2697,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(21,2712,15,10f,-.79f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(11,2712,15,10f,-.79f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(32,2712,15,10f,1.39f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(22,2712,15,10f,1.39f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(10,2716,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(0,2736,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(1,2756,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(2,2776,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(3,2796,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(4,2816,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(5,2836,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(6,2856,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(7,2876,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(8,2896,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(9,2916,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(10,2936,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(21,2936,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(22,2936,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(20,2942,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(23,2942,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(19,2948,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(24,2948,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(21,2954,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(22,2954,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(0,2956,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(18,2960,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(25,2960,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(20,2966,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(23,2966,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(17,2972,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(26,2972,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(1,2976,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(19,2978,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(24,2978,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(16,2984,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(27,2984,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(18,2990,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(25,2990,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(15,2996,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(28,2996,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(2,2996,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(17,3002,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(26,3002,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(14,3008,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(29,3008,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(16,3014,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(27,3014,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(3,3016,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(13,3020,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(30,3020,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(15,3026,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(28,3026,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(12,3032,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(31,3032,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(4,3036,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(14,3038,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(29,3038,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(11,3044,15,10f,-.25f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(32,3044,15,10f,.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(13,3050,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(30,3050,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(11,3056,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(32,3056,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),

            new objectAction(12,3056,15,10f,-.75f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(31,3056,15,10f,1.35f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(33,3056,1,1.3f,.25f,0,false,0,0,0,-.1f,0f,actionType.NEWSHAPE),
            new objectAction(34,3056,1,1.3f,.25f,0,false,0,0,0,-.1f,.82f,actionType.NEWSHAPE),
            new objectAction(5,3056,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(6,3076,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(33,3076,1,1.3f,.25f,0,false,0,0,0,-.1f,0f,actionType.NEWSHAPE),
            new objectAction(34,3076,1,1.3f,.25f,0,false,0,0,0,-.1f,.82f,actionType.NEWSHAPE),
            new objectAction(7,3096,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(8,3116,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),

            new objectAction(9,3136,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.EXPLODEIN),
            new objectAction(10,3156,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.EXPLODEIN),
            new objectAction(0,3176,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(1,3196,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.EXPLODEIN),
            new objectAction(2,3216,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.EXPLODEIN),
            new objectAction(3,3236,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(4,3256,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.EXPLODEIN),
            new objectAction(5,3276,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.EXPLODEIN),
            new objectAction(9,3276,1,10f,0f,0,true,0,0,0,-.5f,0,actionType.EXPLODEOUT),
            new objectAction(10,3276,1,10f,0f,0,false,0,0,0,-.5f,0,actionType.EXPLODEOUT),
            new objectAction(6,3296,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(7,3316,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.EXPLODEIN),
            new objectAction(8,3336,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.EXPLODEIN),
            new objectAction(1,3336,1,10f,0f,0,false,0,0,0,-.5f,0,actionType.EXPLODEOUT),
            new objectAction(2,3336,1,10f,0f,0,true,0,0,0,-.5f,0,actionType.EXPLODEOUT),
            new objectAction(9,3356,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(10,3376,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.EXPLODEIN),
            new objectAction(0,3396,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.EXPLODEIN),
            new objectAction(4,3296,1,10f,0f,0,true,0,0,0,-.5f,0,actionType.EXPLODEOUT),
            new objectAction(5,3296,1,10f,0f,0,false,0,0,0,-.5f,0,actionType.EXPLODEOUT),
            new objectAction(1,3416,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(2,3436,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.EXPLODEIN),
            new objectAction(3,3456,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.EXPLODEIN),
            new objectAction(7,3346,1,10f,0f,0,false,0,0,0,-.5f,0,actionType.EXPLODEOUT),
            new objectAction(8,3346,1,10f,0f,0,true,0,0,0,-.5f,0,actionType.EXPLODEOUT),
            new objectAction(4,3476,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(5,3496,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.EXPLODEIN),
            new objectAction(6,3516,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.EXPLODEIN),
            new objectAction(10,3516,1,10f,0f,0,true,0,0,0,-.5f,0,actionType.EXPLODEOUT),
            new objectAction(0,3516,1,10f,0f,0,false,0,0,0,-.5f,0,actionType.EXPLODEOUT),
            new objectAction(7,3536,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(8,3556,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.EXPLODEIN),
            new objectAction(9,3556,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.EXPLODEIN),
            new objectAction(2,3556,1,10f,0f,0,false,0,0,0,-.5f,0,actionType.EXPLODEOUT),
            new objectAction(3,3556,1,10f,0f,0,true,0,0,0,-.5f,0,actionType.EXPLODEOUT),
            new objectAction(33,3596,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(0,3616,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.EXPLODEIN),
            new objectAction(1,3636,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.EXPLODEIN),
            new objectAction(5,3636,1,10f,0f,0,true,0,0,0,-.5f,0,actionType.EXPLODEOUT),
            new objectAction(6,3636,1,10f,0f,0,false,0,0,0,-.5f,0,actionType.EXPLODEOUT),
            new objectAction(2,3656,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.LASER),
            new objectAction(3,3676,1,10f,0f,0,false,0,0,0,-.1f,0,actionType.EXPLODEIN),
            new objectAction(4,3696,1,10f,0f,0,true,0,0,0,-.1f,0,actionType.EXPLODEIN),
            new objectAction(8,3696,1,10f,0f,0,false,0,0,0,-.5f,0,actionType.EXPLODEOUT),
            new objectAction(9,3696,1,10f,0f,0,true,0,0,0,-.5f,0,actionType.EXPLODEOUT),

            new objectAction(10,3636,1,10f,0f,0,true,0,0,0,-.5f,0,actionType.EXPLODEOUT),
            new objectAction(0,3636,1,10f,0f,0,false,0,0,0,-.5f,0,actionType.EXPLODEOUT),

            new objectAction(3,3736,1,10f,0f,0,false,0,0,0,-.5f,0,actionType.EXPLODEOUT),
            new objectAction(4,3736,1,10f,0f,0,true,0,0,0,-.5f,0,actionType.EXPLODEOUT),
    };
}
