package com.example.lab228.finalproject;


import android.animation.ArgbEvaluator;
import android.animation.ObjectAnimator;
import android.animation.ValueAnimator;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;

import java.util.Random;


public class MainActivity extends AppCompatActivity {
    TextView Title;
    Button select,howTo,credits;
    Animation buttonTouch,buttonOffTouch;
    static Random random = new Random();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View view = getWindow().getDecorView();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            view.setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN);
        }
        setContentView(R.layout.activity_main);
        Title = findViewById(R.id.titleTextView);
        select = findViewById(R.id.playButton);
        howTo = findViewById(R.id.HelpButton);
        credits = findViewById(R.id.CreditsButton);
        buttonTouch = AnimationUtils.loadAnimation(this,R.anim.maintouch);
        buttonOffTouch = AnimationUtils.loadAnimation(this,R.anim.mainofftouch);

        //animation: https://stackoverflow.com/questions/9448732/shaking-wobble-view-animation-in-android
        Title.startAnimation(AnimationUtils.loadAnimation(this,R.anim.rotate));

        try {
            @SuppressLint("ObjectAnimatorBinding") ValueAnimator animator = ObjectAnimator.ofInt(Title, "title", Color.parseColor("#5e5ef9"), Color.parseColor("#FF0000"));
            animator.setEvaluator(new ArgbEvaluator());
            animator.setIntValues(Color.parseColor("#5e5ef9"), Color.parseColor("#FF0000"));
            animator.setDuration(3600);
            animator.setRepeatCount(ValueAnimator.INFINITE);
            animator.setRepeatMode(ValueAnimator.REVERSE);
            animator.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
                @Override
                public void onAnimationUpdate(ValueAnimator animation) {//(int)animator.getAnimatedValue()
                    Title.setTextColor((int) animation.getAnimatedValue());
                }
            });
            animator.start();
        }
        catch (Exception ignored){}

        select.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int action = event.getAction();
                if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                        v.setBackground(getResources().getDrawable(R.color.colorButton));
                    }
                        howTo.clearAnimation();
                        credits.clearAnimation();
                        v.startAnimation(buttonOffTouch);
                    }

                else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                        v.setBackground(getResources().getDrawable(R.color.colorSelectedButton));
                    }
                    try {
                        if (!v.getAnimation().equals(buttonTouch))
                            v.startAnimation(buttonTouch);
                    }
                    catch (NullPointerException e){
                        v.startAnimation(buttonTouch);
                    }
                    }
                    return false;
            }
        });

        howTo.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int action = event.getAction();
                if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                        v.setBackground(getResources().getDrawable(R.color.colorButton));
                    }
                        select.clearAnimation();
                        credits.clearAnimation();
                        v.startAnimation(buttonOffTouch);
                }

                else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                        v.setBackground(getResources().getDrawable(R.color.colorSelectedButton));
                    }
                    try {
                        if (!v.getAnimation().equals(buttonTouch))
                            v.startAnimation(buttonTouch);
                    }
                    catch (NullPointerException e){
                        v.startAnimation(buttonTouch);
                    }
                }
                return false;
            }
        });

        credits.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int action = event.getAction();
                if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                        v.setBackground(getResources().getDrawable(R.color.colorButton));
                    }
                    select.clearAnimation();
                    howTo.clearAnimation();
                    v.startAnimation(buttonOffTouch);
                }

                else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                        v.setBackground(getResources().getDrawable(R.color.colorSelectedButton));
                    }
                    try {
                        if (!v.getAnimation().equals(buttonTouch))
                            v.startAnimation(buttonTouch);
                    }
                    catch (NullPointerException e){
                        v.startAnimation(buttonTouch);
                    }
                }
                return false;
            }
        });
    }

public void onClickButtonLevelSelect(View v){
    Intent intent = new Intent(this, SelectLevel.class);
    startActivity(intent);
    overridePendingTransition(R.anim.left_in,R.anim.left_out);
}

    public void onClickButtonCredits(View v){
        Intent intent = new Intent(this, Credits.class);
        startActivity(intent);
        overridePendingTransition(R.anim.up_in,R.anim.up_out);
    }

    public void onClickButtonTutorial(View v){
        Intent intent = new Intent(this, tutorial.class);
        startActivity(intent);
        overridePendingTransition(R.anim.right_in,R.anim.right_out);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN);
        }
    }


    /*
 switch(random.nextInt(3)){
            case 0:
                overridePendingTransition(R.anim.right_in,R.anim.right_out);
                break;
            case 1:
                overridePendingTransition(R.anim.up_in,R.anim.up_out);
                default:
                    overridePendingTransition(R.anim.left_in,R.anim.left_out);
                    break;
        }
     */
}

