package com.example.lab228.finalproject;

public class levelTest {
    static float normalScale = 100 / 1920f;
    static gameObject[] levelObjects = {
            new gameObject(1.5f,0.5f,normalScale,normalScale,true,false,true,255,232, 128, 18,0),//0
            new gameObject(1.5f,.1f,.1f,normalScale,true,false,true,255,2, 128, 18,0),//1
            new gameObject(1.9f,.9f,.1f,normalScale,true,false,true,255,232, 128, 18,0),//2
            new gameObject(1.5f,0.9f,.1f,normalScale,true,false,true,255,232, 128, 18,0),//3
            new gameObject(1.5f,0.5f,normalScale,normalScale,true,false,true,255,232, 128, 18,0),//4
            new gameObject(1.5f,.1f,.1f,normalScale,true,false,true,255,2, 128, 18,0),//5
            new gameObject(1.9f,.9f,.1f,normalScale,true,false,true,255,232, 128, 18,0),//6
            new gameObject(1.5f,0.9f,.1f,normalScale,true,false,true,255,232, 128, 18,0),//7
            new gameObject(1.5f,0.5f,normalScale,normalScale,true,false,true,255,232, 128, 18,0),//8
            new gameObject(1.5f,.1f,.1f,normalScale,true,false,true,255,2, 128, 18,0),//9
            new gameObject(1.9f,.9f,.1f,normalScale,true,false,true,255,232, 128, 18,0),//10
            new gameObject(1.5f,0.9f,.1f,normalScale,true,false,true,255,232, 128, 18,0),//11
    };

    static objectAction[] levelActions = {
            new objectAction(0,30,60,10f,.1f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(1,30,60,10f,.1f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(0,90,60,10f,.9f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(1,90,60,10f,.9f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(0,150,60,.1f,10f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(1,150,60,.1f,10f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(0,170,60,10f,.5f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(1,170,60,10f,.5f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(0,210,60,.9f,10f,0,true,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(1,210,60,.9f,10f,0,false,0,0,0,0,0,actionType.TRANSLATE),
            new objectAction(2,210,60,.9f,10f,0,true,0,0,0,0,0,actionType.LASER),
            new objectAction(0,300,60,.9f,10f,0,true,0,0,0,0,0,actionType.EXPLODEIN),
            new objectAction(1,310,1,.05f,.05f,255,true,1,200,0,.7f,.5f,actionType.NEWSHAPE),
            new objectAction(1,320,240,.5f,.5f,1080,true,0,0,0,.5f,.5f,actionType.ROTATE),
            new objectAction(0,420,60,.9f,10f,0,true,0,0,0,.5f,.5f,actionType.EXPLODEOUT),
            new objectAction(1,660,240,.5f,.5f,1080,false,0,0,0,.5f,.5f,actionType.ROTATE),
            new objectAction(1,700,60,.5f,.5f,1080,false,5,0,0,.5f,.5f,actionType.SCREENSHAKE),
            new objectAction(2,710,1,.08f,.05f,240,false,0,50,255,.5f,.5f,actionType.NEWSHAPE),
            new objectAction(2,720,60,.5f,.5f,150,false,0,0,0,.5f,.5f,actionType.NEWALPHA),
            new objectAction(3,800,1,.5f,.5f,1080,false,255,255,40,.5f,.5f,actionType.NEWCOLOR),
    };}
