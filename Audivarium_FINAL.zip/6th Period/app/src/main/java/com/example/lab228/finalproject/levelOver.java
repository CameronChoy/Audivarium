package com.example.lab228.finalproject;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.TextView;

import org.w3c.dom.Text;

import java.text.DecimalFormat;

public class levelOver extends AppCompatActivity {
TextView text;
Button buttonQuit,buttonReplay;
Animation buttonTouch;
int levelID = 0;
int minutes=0, seconds=0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        View view = getWindow().getDecorView();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            view.setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN);
        }
        setContentView(R.layout.activity_level_over);

        final Context cont = this;
        text = findViewById(R.id.winLoseTextView);
        buttonQuit = findViewById(R.id.quitbutton);
        buttonReplay = findViewById(R.id.replayButton);
        text.startAnimation(AnimationUtils.loadAnimation(this, R.anim.rotate));
        levelID = getIntent().getIntExtra("levelID", 0);
        if (Levels.totalLevels[levelID].isRandom()) {
            seconds = (int) (getIntent().getIntExtra("frameCount", -60) / ((float) 1000 / 17));
            //Log.i("random",seconds + " " + getIntent().getIntExtra("frameCount", -1));
            while (seconds >= 60) {
                minutes++;
                seconds -= 60;
            }
        }

        if (getIntent().getBooleanExtra("didWin", false)) {
            text.setTextColor(Color.rgb(83, 237, 149));
            text.setText("Level Complete");
            SharedPreferences logs = getSharedPreferences(SelectLevel.logName, MODE_PRIVATE);
            if (levelID == 0) {
                logs.edit().putBoolean(SelectLevel.LevelOne, true);
            } else if (levelID == 1) {
                logs.edit().putBoolean(SelectLevel.LevelTwo, true);
            }
        } else {
            if (Levels.totalLevels[levelID].isRandom()) {//endless
                text.setTextColor(Color.WHITE);
                text.setText("You survived for:\n" + minutes + "m " + seconds + "s");
            } else {
                text.setTextColor(Color.RED);
                text.setText("Level Failed");
            }
        }

        buttonTouch = AnimationUtils.loadAnimation(this, R.anim.maintouch);
        buttonReplay.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int action = event.getAction();
                if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                        v.setBackground(getResources().getDrawable(R.color.colorButton));
                    }

                    buttonQuit.clearAnimation();
                    v.startAnimation(AnimationUtils.loadAnimation(cont, R.anim.mainofftouch));
                } else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                        v.setBackground(getResources().getDrawable(R.color.colorSelectedButton));
                    }
                    try {
                        if (!v.getAnimation().equals(buttonTouch))
                            v.startAnimation(buttonTouch);
                    } catch (NullPointerException e) {
                        v.startAnimation(buttonTouch);
                    }
                }
                return false;
            }
        });

        buttonQuit.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                int action = event.getAction();
                if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                        v.setBackground(getResources().getDrawable(R.color.colorButton));
                    }

                    buttonReplay.clearAnimation();
                    v.startAnimation(AnimationUtils.loadAnimation(cont,R.anim.mainofftouch));
                }

                else {
                    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                        v.setBackground(getResources().getDrawable(R.color.colorSelectedButton));
                    }
                    try {
                        if (!v.getAnimation().equals(buttonTouch))
                            v.startAnimation(buttonTouch);
                    }
                    catch (NullPointerException e){
                        v.startAnimation(buttonTouch);
                    }
                }
                return false;
            }
        });
    }

    public void onClickQuitOver(View v){
        Intent intent = new Intent(this, SelectLevel.class);
        startActivity(intent);
        overridePendingTransition(R.anim.zoom_in,R.anim.zoom_out);
    }

    public void onClickReplay(View v){
        Intent intent = new Intent(this, game.class);
        intent.putExtra("level",levelID);
        startActivity(intent);
        overridePendingTransition(R.anim.screen_transition_in, R.anim.screen_transition_out);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN);
        }
    }
}
