package com.example.lab228.finalproject;

public enum actionType {
    TRANSLATE, // move to new x,y over duration
    LASER,// explode in then out, in narrow path
    ROTATE,//rotate object (visual only)
    EXPLODEIN,//slowing appear
    EXPLODEOUT,//explode and disappear
    RESET,//set to new pos, color, damage, ect
    NEWCOLOR,//new color
    NEWALPHA,
    SCREENSHAKE,// shake the screen
    NEWSHAPE //set to new shape and pos only
}
