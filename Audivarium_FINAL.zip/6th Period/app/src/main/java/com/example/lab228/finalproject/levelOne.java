package com.example.lab228.finalproject;

public class levelOne {
    static float normalScale = 100 / 1920f;
    static int laser = 120;
    static int explode = 96;

    static gameObject[] levelObjects = {
            new gameObject(-0.3f,0.2f,normalScale,normalScale,true,false,true,255,22,219,249,0),//0
            new gameObject(-0.4f,0.5f,normalScale,normalScale,true,false,true,255,22,219,249,0),//1
            new gameObject(-0.5f,0.8f,normalScale,normalScale,true,false,true,255,22,219,249,0),//2
            new gameObject(-0.6f,0.1f,normalScale,normalScale,true,false,true,255,22,219,249,0),//3
            new gameObject(-0.2f,0.6f,normalScale,normalScale,true,false,true,255,22,219,249,0),//4
            new gameObject(-0.4f,0.58f,normalScale,normalScale,true,false,true,255,22,219,249,0),//5
            new gameObject(-0.8f,0.3f,normalScale,normalScale,true,false,true,255,22,219,249,0),//6
            new gameObject(-0.1f,0.65f,normalScale,normalScale,true,false,true,255,22,219,249,0),//7
            new gameObject(-.75f,0.8f,normalScale,normalScale,true,false,true,255,22,219,249,0),//8
            new gameObject(-0.3f,0.2f,normalScale,normalScale,true,false,true,255,22,219,249,0),//9
            new gameObject(-0.4f,0.5f,normalScale,normalScale,true,false,true,255,22,219,249,0),//10
            new gameObject(-0.5f,0.8f,normalScale,normalScale,true,false,true,255,22,219,249,0),//11
            new gameObject(-0.6f,0.1f,normalScale,normalScale,true,false,true,255,22,219,249,0),//12
            new gameObject(-0.2f,0.6f,normalScale,normalScale,true,false,true,255,22,219,249,0),//13
            new gameObject(-0.4f,0.58f,normalScale,normalScale,true,false,true,255,22,219,249,0),//14
            new gameObject(-0.8f,0.3f,normalScale,normalScale,true,false,true,255,22,219,249,0),//15
            new gameObject(-0.1f,0.65f,normalScale,normalScale,true,false,true,255,22,219,249,0),//16
            new gameObject(-.75f,0.8f,normalScale,normalScale,true,false,true,255,22,219,249,0),//17
            new gameObject(.4f,0f,.26f,2f,false,false,false,0,255,0,0,0),//18
            new gameObject(0f,0f,.15f,2f,false,false,false,0,255,0,0,0),//19
            new gameObject(.95f,0f,.5f,2f,false,false,false,0,255,0,0,0),//20
            new gameObject(-.75f,0.8f,normalScale,normalScale,true,false,true,255,22,219,249,0),//21
            new gameObject(-.75f,0.8f,normalScale,normalScale,true,false,true,255,22,219,249,0),//22
            new gameObject(-.75f,0.8f,normalScale,normalScale,true,false,true,255,22,219,249,0),//23
            new gameObject(-.75f,0.8f,normalScale,normalScale,true,false,true,255,22,219,249,0),//24

    };

    /*
       Notes:
       RESET: dX,dY becomes right, bottom
       ROTATION: dX becomes rotation angle

       actionBoolean:
           rotate=isCounterCLockwise
           laser=isVertical
           reset=isSquare
           explodeIn and out = israndomlocation
           translate = stopsInMap (if true does actual speed it should be at)

       SCREENSHAKE: red becomes amount of shake
        rotation becomes newAlpha in reset and newalpha
    */
    static objectAction[] levelActions = {
            new objectAction(0,40,400,2f,10f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(1,45,400,2f,10f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(2,70,400,2f,10f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(3,80,400,2f,10f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(4,81,400,2f,10f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(5,82,400,2f,10f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(6,82,400,2f,10f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(7,82,400,2f,10f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(8,82,400,2f,10f,0,false,0,255,0,0,0,actionType.TRANSLATE),

            new objectAction(0,484,1, normalScale,.2f,255,true,1,219,249,.4f,-.8f,actionType.NEWSHAPE),
            new objectAction(1,484,1, normalScale,.5f,255,true,1,219,249,.58f,-.85f,actionType.NEWSHAPE),
            new objectAction(2,484,1, normalScale,.8f,255,true,1,219,249,.77f,-.5f,actionType.NEWSHAPE),
            new objectAction(3,484,1, normalScale,.1f,255,true,1,219,249,.3f,-.1f,actionType.NEWSHAPE),
            new objectAction(4,484,1, normalScale,.6f,255,true,1,219,249,.12f,-.65f,actionType.NEWSHAPE),
            new objectAction(5,484,1, normalScale,.58f,255,true,1,219,249,.95f,-.77f,actionType.NEWSHAPE),
            new objectAction(6,484,1, normalScale,.3f,255,true,1,219,249,.5f,-.9f,actionType.NEWSHAPE),
            new objectAction(7,484,1, normalScale,.65f,255,true,1,219,249,.38f,-.25f,actionType.NEWSHAPE),
            new objectAction(8,484,1, normalScale,.8f,255,true,1,219,249,.8f,-.3f,actionType.NEWSHAPE),

            new objectAction(0,485,400,10f,2f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(1,485,400,10f,2f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(2,485,400,10f,2f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(3,485,400,10f,2f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(4,485,400,10f,2f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(5,485,400,10f,2f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(6,485,400,10f,2f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(7,485,400,10f,2f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(8,485,400,10f,2f,0,false,0,255,0,0,0,actionType.TRANSLATE),

            new objectAction(0,887,1, normalScale,.2f,255,true,22,219,249,1.1f,.8f,actionType.RESET),
            new objectAction(1,887,1, normalScale,.5f,255,true,22,219,249,1.9f,.85f,actionType.RESET),
            new objectAction(2,887,1, normalScale,.8f,255,true,22,219,249,1.5f,.5f,actionType.RESET),
            new objectAction(3,887,1, normalScale,.1f,255,true,22,219,249,1.4f,.1f,actionType.RESET),
            new objectAction(4,887,1, normalScale,.6f,255,true,22,219,249,1.32f,.6f,actionType.RESET),
            new objectAction(5,887,1, normalScale,.58f,255,true,22,219,249,1.15f,.37f,actionType.RESET),
            new objectAction(6,887,1, normalScale,.3f,255,true,22,219,249,1.75f,.9f,actionType.RESET),
            new objectAction(7,887,1, normalScale,.65f,255,true,22,219,249,1.67f,.25f,actionType.RESET),
            new objectAction(8,887,1, normalScale,.8f,255,true,22,219,249,1.85f,.3f,actionType.RESET),

            new objectAction(0,889,400,-2f,10f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(1,889,400,-2f,10f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(2,889,400,-2f,10f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(3,889,400,-2f,10f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(4,889,400,-2f,10f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(5,889,400,-2f,10f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(6,889,400,-2f,10f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(7,889,400,-2f,10f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(8,889,400,-2f,10f,0,false,0,255,0,0,0,actionType.TRANSLATE),

            new objectAction(9,889-explode,1, normalScale,.2f,0,true,22,219,249,1.5f,.8f,actionType.EXPLODEIN),
            new objectAction(10,950-explode,1, normalScale,.5f,0,true,22,219,249,1.5f,.85f,actionType.EXPLODEIN),
            new objectAction(11,980-explode,1, normalScale,.8f,0,true,22,219,249,1.5f,.5f,actionType.EXPLODEIN),
            new objectAction(12,1050-explode,1, normalScale,.1f,0,true,22,219,249,1.5f,.1f,actionType.EXPLODEIN),
            new objectAction(13,1076-explode,1, normalScale,.6f,0,true,22,219,249,1.5f,.65f,actionType.EXPLODEIN),
            new objectAction(9,1097,400,2f,.8f,0,false,0,255,0,0,0,actionType.EXPLODEOUT),
            new objectAction(14,1100-explode,1, normalScale,.58f,0,true,22,219,249,1.5f,.77f,actionType.EXPLODEIN),
            new objectAction(10,1160,400,2f,.85f,0,false,0,255,0,0,0,actionType.EXPLODEOUT),
            new objectAction(15,1170-explode,1, normalScale,.3f,0,true,22,219,249,1.5f,.9f,actionType.EXPLODEIN),
            new objectAction(11,1190,400,2f,.5f,0,false,0,255,0,0,0,actionType.EXPLODEOUT),
            new objectAction(16,1260-explode,1, normalScale,.65f,0,true,22,219,249,1.5f,.25f,actionType.EXPLODEIN),
            new objectAction(12,1260,400,2f,.1f,0,false,0,255,0,0,0,actionType.EXPLODEOUT),
            new objectAction(13,1266,400,2f,.65f,0,false,0,255,0,0.5f,0.5f,actionType.EXPLODEOUT),
            new objectAction(17,1266-explode,1, normalScale,.8f,0,true,22,219,249,1.5f,3f,actionType.EXPLODEIN),
            new objectAction(14,1310,400,2f,.77f,0,false,0,255,0,0,0,actionType.EXPLODEOUT),
            new objectAction(15,1380,400,2f,.9f,0,false,0,255,0,0,0,actionType.EXPLODEOUT),
            new objectAction(16,1420,400,2f,.25f,0,false,0,255,0,0,0,actionType.EXPLODEOUT),
            new objectAction(17,1420,400,2f,.3f,0,false,0,255,0,0,0,actionType.EXPLODEOUT),

            new objectAction(18,1420,30,2f,.3f,60,false,5,255,0,0,0,actionType.NEWALPHA),
            new objectAction(17,1448,5,2f,.3f,0,false,4,255,0,0,0,actionType.SCREENSHAKE),

            new objectAction(0,1448,1, normalScale,.2f,255,true,22,219,249,.4f,1.5f,actionType.RESET),
            new objectAction(1,1448,1, normalScale,.5f,255,true,22,219,249,.5f,1.5f,actionType.RESET),
            new objectAction(2,1448,1, normalScale,.8f,255,true,22,219,249,.6f,1.5f,actionType.RESET),

            new objectAction(0,1450,100,10f,-2f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(1,1450,100,10f,-2f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(2,1450,100,10f,-2f,0,false,0,255,0,0,0,actionType.TRANSLATE),

            new objectAction(0,1560,1, normalScale,.2f,255,true,22,219,249,.4f,1.5f,actionType.RESET),
            new objectAction(1,1560,1, normalScale,.5f,255,true,22,219,249,.5f,1.5f,actionType.RESET),
            new objectAction(2,1560,1, normalScale,.8f,255,true,22,219,249,.6f,1.5f,actionType.RESET),

            new objectAction(1,1561,5,2f,.3f,0,false,4,255,0,0,0,actionType.SCREENSHAKE),
            new objectAction(0,1562,100,10f,-2f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(1,1562,100,10f,-2f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(2,1562,100,10f,-2f,0,false,0,255,0,0,0,actionType.TRANSLATE),

            new objectAction(19,1600,30,2f,.3f,60,false,5,255,0,0,0,actionType.NEWALPHA),
            new objectAction(18,1600,30,2f,.3f,0,false,5,255,0,0,0,actionType.NEWALPHA),

            new objectAction(0,1664,1, normalScale,.2f,255,true,22,219,249,-.5f,0.1f,actionType.RESET),
            new objectAction(1,1664,1, normalScale,.5f,255,true,22,219,249,-.5f,.35f,actionType.RESET),
            new objectAction(2,1664,1, normalScale,.8f,255,true,22,219,249,-.5f,.6f,actionType.RESET),
            new objectAction(3,1664,1, normalScale,.1f,255,true,22,219,249,-.5f,.85f,actionType.RESET),

            new objectAction(0,1666,100,2f,10f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(1,1666,100,2f,10f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(2,1666,100,2f,10f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(3,1666,100,2f,10f,0,false,0,255,0,0,0,actionType.TRANSLATE),

            new objectAction(19,1680,30,2f,.3f,0,false,5,255,0,0,0,actionType.NEWALPHA),
            new objectAction(20,1680,30,2f,.3f,60,false,5,255,0,0,0,actionType.NEWALPHA),

            new objectAction(0,1766,100,-2f,10f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(1,1766,100,-2f,10f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(2,1766,100,-2f,10f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(3,1766,100,-2f,10f,0,false,0,255,0,0,0,actionType.TRANSLATE),

            new objectAction(20,1780,30,2f,.3f,0,false,5,255,0,0,0,actionType.NEWALPHA),

            new objectAction(4,1925-laser,100,.5f,10f,0,true,0,255,0,0,0,actionType.LASER),
            new objectAction(5,1925-laser,100,.3f,10f,0,true,0,255,0,0,0,actionType.LASER),
            new objectAction(6,1925-laser,100,.7f,10f,0,true,0,255,0,0,0,actionType.LASER),

            new objectAction(7,1947-laser,100,.7f,.25f,0,false,0,255,0,0,0,actionType.LASER),
            new objectAction(8,1947-laser,100,.7f,.5f,0,false,0,255,0,0,0,actionType.LASER),
            new objectAction(9,1947-laser,100,.7f,.75f,0,false,0,255,0,0,0,actionType.LASER),

            new objectAction(0,1948,1, normalScale,.2f,255,true,22,219,249,.55f,-.3f,actionType.RESET),
            new objectAction(1,1948,1, normalScale,.5f,255,true,22,219,249,.55f,-.3f,actionType.RESET),
            new objectAction(2,1948,1, normalScale,.2f,255,true,22,219,249,.85f,-.3f,actionType.RESET),
            new objectAction(3,1948,1, normalScale,.5f,255,true,22,219,249,.15f,-.3f,actionType.RESET),

            new objectAction(0,1950,180,0.5f,.5f,360,false,0,255,0,-1f,-1f,actionType.ROTATE),
            new objectAction(1,1950,180,0.5f,.5f,360,true,0,255,0,-1f,-1f,actionType.ROTATE),
            new objectAction(2,1950,100,10f,1.5f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(3,1950,100,10f,1.5f,0,false,0,255,0,0,0,actionType.TRANSLATE),

            new objectAction(13,1960-explode,1, normalScale,.2f,0,true,22,219,249,.5f,.5f,actionType.EXPLODEIN),
            new objectAction(10,1975-explode,1, normalScale,.2f,0,true,22,219,249,.5f,.8f,actionType.EXPLODEIN),

            new objectAction(11,1990-explode,1, normalScale,.2f,0,true,22,219,249,.5f,.8f,actionType.EXPLODEIN),
            new objectAction(12,2005-explode,1, normalScale,-1.5f,0,true,22,219,249,.5f,.8f,actionType.EXPLODEIN),
            new objectAction(14,2020-explode,1, normalScale,-1.5f,0,true,22,219,249,.5f,.8f,actionType.EXPLODEIN),
            new objectAction(15,2035-explode,1, normalScale,-1.5f,0,true,22,219,249,.5f,.8f,actionType.EXPLODEIN),
            new objectAction(16,2050-explode,1, normalScale,-1.5f,0,true,22,219,249,.5f,.8f,actionType.EXPLODEIN),
            new objectAction(17,2065-explode,1, normalScale,-1.5f,0,true,22,219,249,.5f,.8f,actionType.EXPLODEIN),
            new objectAction(6,2130-laser,100,0f,.3f,0,false,0,255,0,0,0,actionType.LASER),
            new objectAction(7,2160-laser,100,0f,.7f,0,false,0,255,0,0,0,actionType.LASER),
            new objectAction(22,2190-laser,100,.3f,0f,0,true,0,255,0,0,0,actionType.LASER),
            new objectAction(13,2080,120, 10f,-1.5f,0,false,22,219,249,1.5f,.8f,actionType.TRANSLATE),
            new objectAction(23,2210-laser,100,.6f,0f,0,true,0,255,0,0,0,actionType.LASER),
            new objectAction(10,2095,120, 10f,-1.5f,0,false,22,219,249,1.5f,.8f,actionType.TRANSLATE),
            new objectAction(11,2110,120, 10f,-1.5f,0,false,22,219,249,1.5f,.8f,actionType.TRANSLATE),
            new objectAction(24,2240-laser,100,.9f,0f,0,true,0,255,0,0,0,actionType.LASER),
            new objectAction(12,2125,120, 10f,-1.5f,0,false,22,219,249,1.5f,.8f,actionType.TRANSLATE),
            new objectAction(14,2140,120, 10f,-1.5f,0,false,22,219,249,1.5f,.8f,actionType.TRANSLATE),
            new objectAction(0,2270-laser,100,0f,0.15f,0,false,0,255,0,0,0,actionType.LASER),
            new objectAction(15,2155,120, 10f,-1.5f,0,false,22,219,249,1.5f,.8f,actionType.TRANSLATE),
            new objectAction(1,2300-laser,100,0f,0.5f,0,false,0,255,0,0,0,actionType.LASER),
            new objectAction(16,2170,120, 10f,-1.5f,0,false,22,219,249,1.5f,.8f,actionType.TRANSLATE),
            new objectAction(17,2195,120, 10f,-1.5f,0,false,22,219,249,1.5f,.8f,actionType.TRANSLATE),
            new objectAction(2,2330-laser,100,0f,0.85f,0,false,0,255,0,0,0,actionType.LASER),

            new objectAction(19,2220,1,.25f,1.5f,0,false,22,219,249,0,0,actionType.NEWSHAPE),
            new objectAction(18,2220,1,.4f,1.5f,0,false,22,219,249,.85f,0,actionType.NEWSHAPE),
            new objectAction(19,2230,30, normalScale,.5f,60,true,0,219,249,.15f,-.3f,actionType.NEWALPHA),
            new objectAction(18,2230,30, normalScale,.5f,60,true,0,219,249,.15f,-.3f,actionType.NEWALPHA),

            new objectAction(6,2463-laser,100,.3f,0f,0,true,0,255,0,0,0,actionType.LASER),
            new objectAction(7,2483-laser,100,.75f,0f,0,true,0,255,0,0,0,actionType.LASER),

            new objectAction(21,2240,1, .5f,1.5f,255,false,22,219,249,-.55f,0f,actionType.RESET),
            new objectAction(22,2240,1, .4f,1.5f,255,false,22,219,249,1.7f,0f,actionType.RESET),
            new objectAction(21,2400,15, -0.22f,10f,0,true,22,219,249,1.5f,.8f,actionType.TRANSLATE),
            new objectAction(22,2400,15, .86f,10f,0,true,22,219,249,1.5f,.8f,actionType.TRANSLATE),
            new objectAction(4,2510-explode,1, normalScale,.65f,0,true,22,219,249,1.5f,.25f,actionType.EXPLODEIN),

            new objectAction(21,2416,12, -.25f,10f,0,true,22,219,249,1.5f,.8f,actionType.TRANSLATE),
            new objectAction(22,2416,12, .84f,10f,0,true,22,219,249,1.5f,.8f,actionType.TRANSLATE),
            new objectAction(19,2430,30, normalScale,.5f,0,true,0,219,249,.15f,-.3f,actionType.NEWALPHA),
            new objectAction(18,2430,30, normalScale,.5f,0,true,0,219,249,.15f,-.3f,actionType.NEWALPHA),

            new objectAction(21,2430,15, -1.6f,10f,0,false,22,219,249,1.5f,.8f,actionType.TRANSLATE),
            new objectAction(22,2430,15, 1.6f,10f,0,false,22,219,249,1.5f,.8f,actionType.TRANSLATE),

            new objectAction(0,2431,1, normalScale,.2f,255,true,22,219,249,.55f,1.3f,actionType.RESET),
            new objectAction(1,2431,1, normalScale,.5f,255,true,22,219,249,.55f,1.3f,actionType.RESET),
            new objectAction(2,2431,1, normalScale,.2f,255,true,22,219,249,.95f,1.3f,actionType.RESET),
            new objectAction(3,2431,1, normalScale,.5f,255,true,22,219,249,.15f,1.3f,actionType.RESET),

            new objectAction(5,2540-explode,1, normalScale,.65f,0,true,22,219,249,1.5f,.25f,actionType.EXPLODEIN),
            new objectAction(8,2570-explode,1, normalScale,.65f,0,true,22,219,249,1.5f,.25f,actionType.EXPLODEIN),
            new objectAction(4,2474,170,1.5f,10f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(9,2600-explode,1, normalScale,.65f,0,true,22,219,249,1.5f,.25f,actionType.EXPLODEIN),
            new objectAction(5,2504,170,10f,1.5f,0,false,0,255,0,0,0,actionType.TRANSLATE),

            new objectAction(0,2510,180,0.5f,.5f,360,true,0,255,0,-1f,-1f,actionType.ROTATE),
            new objectAction(1,2510,180,0.5f,.5f,360,false,0,255,0,-1f,-1f,actionType.ROTATE),
            new objectAction(2,2510,100,10f,-1.5f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(3,2510,100,10f,-1.5f,0,false,0,255,0,0,0,actionType.TRANSLATE),

            new objectAction(10,2630-explode,1, normalScale,.65f,0,true,22,219,249,1.5f,.25f,actionType.EXPLODEIN),
            new objectAction(8,2504,170,-1.5f,10f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(11,2660-explode,1, normalScale,.65f,0,true,22,219,249,1.5f,.25f,actionType.EXPLODEIN),
            new objectAction(9,2564,170,10f,-1.5f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(6,2690-explode,1, normalScale,.65f,0,true,22,219,249,1.5f,.25f,actionType.EXPLODEIN),
            new objectAction(10,2594,170,1.5f,10f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(12,2710-explode,1, normalScale,.65f,0,true,22,219,249,1.5f,.25f,actionType.EXPLODEIN),
            new objectAction(11,2624,170,10f,1.5f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(6,2654,170,-1.5f,10f,0,false,0,255,0,0,0,actionType.TRANSLATE),
            new objectAction(12,2674,170,10f,-1.5f,0,false,0,255,0,0,0,actionType.TRANSLATE)
    };
}
