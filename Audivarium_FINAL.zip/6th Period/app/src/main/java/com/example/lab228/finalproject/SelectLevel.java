package com.example.lab228.finalproject;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Build;
import android.os.Handler;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import java.util.Random;


public class SelectLevel extends AppCompatActivity {

    HorizontalScrollView scrollView;
    LinearLayout layout;
    Button right, left;
    float screenScale;
    Button level;
    Random random = new Random();
    SpannableString infoText;
    RelativeSizeSpan textSpan = new RelativeSizeSpan(.7f);
    SharedPreferences logs;
    static String logName = "logs";
    static String LevelOne = "lvlOne";
    static String LevelTwo = "lvlTwo";
    boolean canSelect;
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        canSelect=true;
        super.onCreate(savedInstanceState);
        View view = getWindow().getDecorView();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            view.setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN);
        }
        logs = getSharedPreferences(logName,MODE_PRIVATE);
        final Animation anim = (AnimationUtils.loadAnimation(this,R.anim.levelrotate));
        //final Animation TOUCHING = (AnimationUtils.loadAnimation(this,R.anim.touching));
        //final Animation TOUCHCANCEL = AnimationUtils.loadAnimation(this,R.anim.offtouch);

        setContentView(R.layout.activity_select_level);
        final Context cont = this;
        layout = findViewById(R.id.linearSelect);
        if(logs.getBoolean(LevelOne,false) && logs.getBoolean(LevelTwo,false)){
            layout.setBackgroundColor(Color.rgb(56, 105, 183));
        }
        screenScale = getApplicationContext().getResources().getDisplayMetrics().density;
        scrollView = findViewById(R.id.scroll);

        right=findViewById(R.id.buttonRight);
        left=findViewById(R.id.buttonLeft);
        layout = findViewById(R.id.scrollLinear);
        LinearLayout.LayoutParams param = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        param.setMargins(0,0,60,0);

        layout.setClipChildren(false);
        layout.setClipToPadding(false);
        for(int i = 0; i < Levels.totalLevels.length; i++){
            level = new Button(this);
            level.setLayoutParams(param);

            infoText = new SpannableString("Level " + (i+1) + ": \n" + Levels.totalLevels[i].getTitle() + "\n" + Levels.totalLevels[i].getExtraInfo());
            infoText.setSpan(textSpan,infoText.length()-Levels.totalLevels[i].getExtraInfo().length(),infoText.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);

            if(!Levels.totalLevels[i].isRandom()){
                level.setTextColor(Color.rgb(Levels.totalLevels[i].getRed(),Levels.totalLevels[i].getGreen(),Levels.totalLevels[i].getBlue()));
                infoText.setSpan(new ForegroundColorSpan(Levels.totalLevels[i].getPlayerColor()),infoText.length()-Levels.totalLevels[i].getExtraInfo().length(),infoText.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);}
            else{
                level.setTextColor(Color.argb(255,random.nextInt(200)+56,random.nextInt(200)+56,random.nextInt(200)+56));
                infoText.setSpan(new ForegroundColorSpan(Color.argb(255,random.nextInt(200)+56,random.nextInt(200)+56,random.nextInt(200)+56)),
                        infoText.length()-Levels.totalLevels[i].getExtraInfo().length(),infoText.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
            }

            level.setText(infoText);
            level.setTextSize(getResources().getDimension(R.dimen.levelTextSize));
            level.setWidth((int)(250*screenScale));
            level.setHeight((int)(150*screenScale));

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                level.setBackground(getResources().getDrawable(R.color.colorButton));
            }

            final int levelId = i;
          level.setOnTouchListener(new View.OnTouchListener() {
              boolean isTouching = false;
              @Override
              public boolean onTouch(View v, MotionEvent event) {
                  int action = event.getAction();
                  if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
                      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                          v.setBackground(getResources().getDrawable(R.color.colorButton));
                      }
                      if(isTouching) {
                          v.startAnimation(AnimationUtils.loadAnimation(cont,R.anim.offtouch));
                          isTouching=false;
                          //Log.i("touching","up");
                      }
                  }

                    else {
                      if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
                      v.setBackground(getResources().getDrawable(R.color.colorSelectedButton));
                      }
                      if(!isTouching) {
                          v.startAnimation(AnimationUtils.loadAnimation(cont,R.anim.touching));
                          isTouching=true;
                         //Log.i("touching","down");
                      }
              }
                    return false;
                }
            });

          level.setOnClickListener(new View.OnClickListener() {
                                       @Override
                                       public void onClick(View v) {
                                           if (canSelect) {
                                               canSelect = false;
                                               Intent intent = new Intent(cont, game.class);
                                               intent.putExtra("level", levelId);
                                               startActivity(intent);
                                               overridePendingTransition(R.anim.screen_transition_in, R.anim.screen_transition_out);
                                           }
                                       }
                                   });

            layout.addView(level);
            level.startAnimation(anim);
            //level.getAnimation().setDuration(anim.getDuration()+ random.nextInt(100));
            //level.setAnimation(AnimationUtils.loadAnimation(cont,R.anim.levelrotate));
        }

        left.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_DOWN){
                    scrollView.scrollBy(-1500,0);
                }
                return false;
            }
        });

        right.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if(event.getAction() == MotionEvent.ACTION_DOWN){
                    scrollView.scrollBy(1500,0);
                }
                return false;
            }
        });

    }

    public void onClickButtonBack(View v){
        Intent intent = new Intent(this,MainActivity.class);
        startActivity(intent);
        overridePendingTransition(R.anim.up_in,R.anim.up_out);
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT) {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN);
        }
    }
    /* Intent intent = new Intent(cont,game.class);
                    intent.putExtra("level",levelId);
                    try{
                        Thread.sleep(250);
                    }
                    catch (InterruptedException ignored){}
                    startActivity(intent);
                    overridePendingTransition(android.R.anim.fade_in,android.R.anim.fade_out);
                    */

}
