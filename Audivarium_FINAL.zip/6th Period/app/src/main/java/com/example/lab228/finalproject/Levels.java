package com.example.lab228.finalproject;

import android.graphics.Color;

import java.util.Random;

public class Levels {
    private gameObject[] levelObjects;
    private objectAction[] levelActions;
    private int songId, red, green, blue, playerColor;
    private String Title, extraInfo;
    private boolean isRandom;

    public Levels(gameObject[] objects, objectAction[] actions, String Title, int songId, int playerColor,boolean random, String extraInfo) {
        levelObjects = objects;
        levelActions = actions;
        this.songId = songId;
        this.Title=Title;
        this.extraInfo=extraInfo;
        this.playerColor=playerColor;
        red=(int)levelObjects[0].getRed();
        green=(int)levelObjects[0].getGreen();
        blue=(int)levelObjects[0].getBlue();
        isRandom=random;
    }

    public int getPlayerColor(){return playerColor;}
    public String getTitle() { return Title; }
    public gameObject[] getObjects() { return levelObjects; }
    public objectAction[] getLevelActions() { return levelActions; }
    public int getSongId() { return songId; }
    public int getBlue(){return blue;}
    public int getGreen() { return green; }
    public int getRed() { return red; }
    public boolean isRandom() { return isRandom; }
    public String getExtraInfo() { return extraInfo; }

    static Levels[] totalLevels = new Levels[]{
            new Levels(levelOne.levelObjects, levelOne.levelActions, "Stardust", R.raw.stardust, Color.RED,false,"Easy"),
            new Levels(levelTwo.levelObjects, levelTwo.levelActions, "Chaoz Impact", R.raw.chaozimpact, Color.rgb(176, 112, 255),false,"Less Easy"),
            new Levels(levelTest.levelObjects, levelTest.levelActions, "Survive", R.raw.theshow, Color.WHITE,true,"Endless chaos"),
    };


}


