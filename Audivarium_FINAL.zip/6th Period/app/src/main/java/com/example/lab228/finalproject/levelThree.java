package com.example.lab228.finalproject;

public class levelThree {
    static float normalScale = 100 / 1920f;
    static gameObject[] levelObjects = {
            new gameObject(0.1f,0f,normalScale,normalScale,true,false,true,255,204, 55, 44,0),//0
            new gameObject(.2f,0f,normalScale,normalScale,true,false,true,255,204, 55, 44,0),//1
            new gameObject(.3f,0f,normalScale,normalScale,true,false,true,255,204, 55, 44,0),//2
            new gameObject(.4f,0f,normalScale,normalScale,true,false,true,255,204, 55, 44,0),//3
            new gameObject(.5f,0f,normalScale,normalScale,true,false,true,60,255, 0, 0,0),//4
            new gameObject(.6f,0f,normalScale,normalScale,true,false,true,255,204, 55, 44,0),//5
            new gameObject(.7f,0f,normalScale,normalScale,true,false,true,255,204, 55, 44,0),//6
            new gameObject(.8f,0f,normalScale,normalScale,true,false,true,255,204, 55, 44,0),//7
            new gameObject(.9f,0f,normalScale,normalScale,true,false,true,255,204, 55, 44,0),//8
            new gameObject(.1f,.2f,normalScale,normalScale,true,false,true,255,204, 55, 44,0),//9
            new gameObject(.2f,.2f,normalScale,normalScale,true,false,true,255,204, 55, 44,0),//10
            new gameObject(.3f,.2f,normalScale,normalScale,true,false,true,255,204, 55, 44,0),//11
            new gameObject(.4f,.2f,normalScale,normalScale,true,false,true,255,204, 55, 44,0),//12
            new gameObject(.5f,.2f,normalScale,normalScale,true,false,true,255,204, 55, 44,0),//13
            new gameObject(.6f,.2f,normalScale,normalScale,true,false,true,255,204, 55, 44,0),//14
            new gameObject(.7f,.2f,normalScale,normalScale,true,false,true,255,204, 55, 44,0),//15
            new gameObject(.8f,.2f,normalScale,normalScale,true,false,true,255,204, 55, 44,0),//16
            new gameObject(.9f,.2f,normalScale,normalScale,true,false,true,255,204, 55, 44,0),//17
            new gameObject(.1f,.4f,normalScale,normalScale,true,false,true,255,104, 105, 44,0),//18
            new gameObject(.2f,.4f,normalScale,normalScale,true,false,true,255,204, 55, 44,0),//19
            new gameObject(.3f,.4f,normalScale,normalScale,true,false,true,255,204, 55, 44,0),//20
            new gameObject(.4f,.4f,normalScale,normalScale,true,false,true,255,204, 55, 44,0),//21
            new gameObject(.5f,.4f,normalScale,normalScale,true,false,true,255,204, 55, 44,0),//22
            new gameObject(.6f,.4f,normalScale,normalScale,true,false,true,255,204, 55, 44,0),//23
            new gameObject(.7f,.4f,normalScale,normalScale,true,false,true,155,204, 55, 44,0),//24
            new gameObject(.8f,.4f,normalScale,normalScale,true,false,true,255,204, 55, 44,0),//25
            new gameObject(.9f,.4f,normalScale,normalScale,true,false,true,255,204, 55, 44,0),//26
            new gameObject(.1f,.6f,normalScale,normalScale,true,false,true,255,204, 55, 44,0),//27
            new gameObject(.2f,.6f,normalScale,normalScale,true,false,true,255,204, 55, 44,0),//28
            new gameObject(.3f,.6f,normalScale,normalScale,true,false,true,255,204, 55, 44,0),//29
    };
    static objectAction[] levelActions = {

    };
}
